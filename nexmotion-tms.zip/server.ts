import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

import {
  MOCK_USERS,
  MOCK_DOCUMENTS,
  MOCK_TENDERS,
  MOCK_TASKS,
  MOCK_ACCESS_LOGS,
  MOCK_EMAIL_ALERTS,
  MOCK_ANALYTICS
} from './src/mockData';

import {
  Tender,
  Task,
  User,
  Document,
  AccessLog,
  EmailAlert,
  MonthlyAnalytics,
  Comment,
  TenderStatus
} from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Database file path
const DB_FILE = path.join(process.cwd(), 'data-store.json');

interface Database {
  users: User[];
  documents: Document[];
  tenders: Tender[];
  tasks: Task[];
  accessLogs: AccessLog[];
  emailAlerts: EmailAlert[];
  analytics: MonthlyAnalytics[];
}

let dbState: Database = {
  users: MOCK_USERS,
  documents: MOCK_DOCUMENTS,
  tenders: MOCK_TENDERS,
  tasks: MOCK_TASKS,
  accessLogs: MOCK_ACCESS_LOGS,
  emailAlerts: MOCK_EMAIL_ALERTS,
  analytics: MOCK_ANALYTICS,
};

// Load database from file if exists, otherwise save current initial state
function loadDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      dbState = JSON.parse(data);
      console.log('Database loaded successfully from', DB_FILE);
    } else {
      saveDb();
      console.log('Created new database file with initial mock data at', DB_FILE);
    }
  } catch (err) {
    console.error('Error loading database:', err);
  }
}

function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving database:', err);
  }
}

// Initial DB load
loadDb();

// Active User session simulation
// We support switching users via Cookie, query, or custom header X-Test-User-Id
let activeUserId = 'user_ceo'; // Default to CEO for full access out of the box

app.use((req, res, next) => {
  const queryUserId = req.query.userId || req.headers['x-test-user-id'];
  if (queryUserId && typeof queryUserId === 'string') {
    const userExists = dbState.users.find(u => u.id === queryUserId);
    if (userExists) {
      activeUserId = queryUserId;
    }
  }
  next();
});

// Helper to get active user object and role
function getActiveUser(): User {
  return dbState.users.find(u => u.id === activeUserId) || dbState.users[0];
}

// Helper to create an email alert audit log
function sendSimulatedEmail(to: string, subject: string, body: string, type: 'deadline' | 'expiry' | 'assignment') {
  const newAlert: EmailAlert = {
    id: 'alert_' + Math.random().toString(36).substr(2, 9),
    to,
    subject,
    body,
    sentAt: new Date().toISOString(),
    type,
  };
  dbState.emailAlerts.unshift(newAlert);
  saveDb();
  console.log(`[Simulated Email Sent] To: ${to} | Subject: ${subject}`);
  return newAlert;
}

// Initialize Gemini Client
const aiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (aiKey && aiKey !== 'MY_GEMINI_API_KEY') {
  try {
    aiClient = new GoogleGenAI({
      apiKey: aiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('Gemini AI Client initialized successfully.');
  } catch (err) {
    console.error('Failed to initialize Gemini AI Client:', err);
  }
} else {
  console.log('No valid GEMINI_API_KEY found. Running in simulated AI mode.');
}

// API Endpoints

// Auth Endpoints
app.get('/api/me', (req, res) => {
  const queryUserId = req.query.userId || req.headers['x-test-user-id'];
  
  // Exclude Calvin, Sibusiso, and Thabo from being listed anywhere in the application
  const filteredUsers = dbState.users.filter(u => {
    const emailLower = u.email.toLowerCase();
    const nameLower = u.name.toLowerCase();
    const isHidden = 
      emailLower === 'costacalvin0321@gmail.com' ||
      emailLower === 'sibusiso@nexmotion.co.za' ||
      emailLower === 'thabo@nexmotion.co.za' ||
      nameLower.includes('calvin costa') ||
      nameLower.includes('sibusiso khumalo') ||
      nameLower.includes('thabo molefe');
    return !isHidden;
  });

  if (!queryUserId || queryUserId === 'null' || queryUserId === 'undefined') {
    return res.json({ user: null, allUsers: filteredUsers });
  }
  const user = dbState.users.find(u => u.id === queryUserId) || null;
  res.json({ user, allUsers: filteredUsers });
});

app.post('/api/auth/login-by-email', (req, res) => {
  const { email, pin, role } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email address is required' });
  }

  const emailLower = email.toLowerCase();
  let user = dbState.users.find(u => u.email.toLowerCase() === emailLower);

  // If user is one of the specific three, let's find or dynamically provision them privately if they were deleted or missing
  if (!user) {
    if (emailLower === 'costacalvin0321@gmail.com') {
      user = {
        id: 'user_ceo',
        name: 'Calvin Costa',
        email: 'costacalvin0321@gmail.com',
        role: role || 'ceo',
        createdAt: new Date().toISOString(),
        defaultDocumentIds: {},
      };
      dbState.users.push(user);
      saveDb();
    } else if (emailLower === 'sibusiso@nexmotion.co.za' || emailLower.startsWith('sibusiso@')) {
      user = {
        id: 'user_pm',
        name: 'Sibusiso Khumalo',
        email: 'sibusiso@nexmotion.co.za',
        role: role || 'pm',
        createdAt: new Date().toISOString(),
        defaultDocumentIds: {},
      };
      dbState.users.push(user);
      saveDb();
    } else if (emailLower === 'thabo@nexmotion.co.za' || emailLower.startsWith('thabo@')) {
      user = {
        id: 'user_viewer',
        name: 'Thabo Molefe',
        email: 'thabo@nexmotion.co.za',
        role: role || 'viewer',
        createdAt: new Date().toISOString(),
        defaultDocumentIds: {},
      };
      dbState.users.push(user);
      saveDb();
    }
  }

  // Pin validation for next motion domain emails or emails containing 'nexmotion'
  const isNexMotion = emailLower.includes('nexmotion') || emailLower.endsWith('.co.za');
  if (isNexMotion) {
    if (pin !== '3456769') {
      return res.status(401).json({ error: 'Access denied: Invalid security PIN for NexMotion corporate account.' });
    }
  }

  if (!user) {
    // If someone types another corporate email, auto-create a profile for them to explore
    user = {
      id: 'user_' + Math.random().toString(36).substr(2, 9),
      name: emailLower.split('@')[0].toUpperCase(),
      email: emailLower,
      role: role || 'pm',
      createdAt: new Date().toISOString(),
      defaultDocumentIds: {},
    };
    dbState.users.push(user);
    saveDb();
  }

  // Dynamically switch user role based on corporate workspace choice at login
  if (user && role) {
    user.role = role as any;
    saveDb();
  }

  activeUserId = user.id;
  res.json({ success: true, user });
});

app.post('/api/auth/switch-user', (req, res) => {
  const { userId } = req.body;
  const user = dbState.users.find(u => u.id === userId);
  if (user) {
    activeUserId = userId;
    res.json({ success: true, user });
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

app.post('/api/auth/signup', (req, res) => {
  const { name, email, role } = req.body;
  if (!name || !email || !role) {
    return res.status(400).json({ error: 'Missing name, email, or role' });
  }

  const emailLower = email.toLowerCase();
  const userExists = dbState.users.find(u => u.email.toLowerCase() === emailLower);
  if (userExists) {
    return res.status(400).json({ error: 'A user with this email address already exists.' });
  }

  const newUser: User = {
    id: 'user_' + Math.random().toString(36).substr(2, 9),
    name,
    email: emailLower,
    role: role,
    createdAt: new Date().toISOString(),
    defaultDocumentIds: {},
  };

  dbState.users.push(newUser);
  activeUserId = newUser.id; // Log in as the newly created user!
  saveDb();
  res.json({ success: true, user: newUser });
});

// Tenders Endpoints
app.get('/api/tenders', (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    // Only return tenders explicitly assigned to them
    const filtered = dbState.tenders.filter(t => t.assignedTo.includes(user.id));
    return res.json(filtered);
  }
  res.json(dbState.tenders);
});

app.get('/api/tenders/:id', (req, res) => {
  const { id } = req.params;
  const tender = dbState.tenders.find(t => t.id === id);
  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer' && !tender.assignedTo.includes(user.id)) {
    return res.status(403).json({ error: 'Access denied: You are not assigned to this tender.' });
  }

  res.json(tender);
});

// AI analysis prompt definition and helper
async function performAIAnalysis(tenderInfo: {
  title: string;
  source: string;
  municipality: string;
  province: string;
  category: string;
  budgetMin: number;
  budgetMax: number;
}) {
  const prompt = `You are an expert Tender Bid Specialist and AI Consultant specializing in South African Government ICT procurements (PFMA, MFMA, and Treasury regulations).
  Analyze the following newly discovered government tender and produce a highly detailed, professional analysis.

  TENDER DETAILS:
  Title: "${tenderInfo.title}"
  Source: "${tenderInfo.source}"
  Municipality/Organ: "${tenderInfo.municipality}"
  Province: "${tenderInfo.province}"
  Category: "${tenderInfo.category}"
  Budget Range: R${tenderInfo.budgetMin} - R${tenderInfo.budgetMax}

  Please generate:
  1. extractedRequirements: An exhaustive list of technical and formal requirements extracted from this brief (e.g., specific hardware/software counts, partnership statuses, certifications).
  2. complianceNeeds: The core compliance documents needed (e.g., SARS tax pin, B-BBEE affidavit, PI insurance, audited statements).
  3. evaluationCriteria: The likely Treasury scoring model (e.g. 80/20 or 90/10) and specific functionality criteria to score.
  4. capabilityMatch: How a modern ICT services company (NexMotion Technologies, which has deep software engineering, cloud migration, and infrastructure support capabilities) matches up to these requirements.
  5. fitScore: A realistic fit score (0-100) based on NexMotion's capabilities.
  6. fitScoreBreakdown: { technical, compliance, timeline, budget } adding up to 100% weights (technical 40%, compliance 30%, timeline 20%, budget 10%).
  7. risks: Concrete risks identified (e.g. strict SLA penalties, cashflow strain for large hardware supplies, geographical support distance).
  8. recommendation: "Pursue" (high score > 80), "Maybe" (score 65-80), or "Skip" (score < 65).

  Your response must be in strict JSON format matching the schema of our system. Do not write any markdown outside the JSON.
  `;

  if (aiClient) {
    try {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              extractedRequirements: { type: Type.ARRAY, items: { type: Type.STRING } },
              complianceNeeds: { type: Type.ARRAY, items: { type: Type.STRING } },
              evaluationCriteria: { type: Type.ARRAY, items: { type: Type.STRING } },
              capabilityMatch: { type: Type.ARRAY, items: { type: Type.STRING } },
              fitScore: { type: Type.INTEGER },
              fitScoreBreakdown: {
                type: Type.OBJECT,
                properties: {
                  technical: { type: Type.INTEGER },
                  compliance: { type: Type.INTEGER },
                  timeline: { type: Type.INTEGER },
                  budget: { type: Type.INTEGER }
                },
                required: ['technical', 'compliance', 'timeline', 'budget']
              },
              risks: { type: Type.ARRAY, items: { type: Type.STRING } },
              recommendation: { type: Type.STRING }
            },
            required: [
              'extractedRequirements',
              'complianceNeeds',
              'evaluationCriteria',
              'capabilityMatch',
              'fitScore',
              'fitScoreBreakdown',
              'risks',
              'recommendation'
            ]
          }
        }
      });

      const responseText = response.text;
      if (responseText) {
        return JSON.parse(responseText.trim());
      }
    } catch (err) {
      console.error('Error with Gemini AI call, using fallback simulator:', err);
    }
  }

  // Fallback simulator if Gemini is not set up or fails
  const score = Math.floor(Math.random() * 30) + 70; // 70-100
  const recommendations: ('Pursue' | 'Maybe' | 'Skip')[] = score >= 85 ? ['Pursue'] : ['Maybe'];
  return {
    extractedRequirements: [
      `Valid SARS Tax Pin and Level 1 or 2 B-BBEE recognition.`,
      `Minimum 5 years of active corporate operations in ICT ${tenderInfo.category}.`,
      `Full technical compliance with detailed hardware / software SLA requirements.`,
      `Provision of fully qualified, accredited engineer CVs (e.g. MCSE, AWS Cloud Practitioner).`
    ],
    complianceNeeds: [
      'SARS Tax Clearance Status Pin',
      'B-BBEE Verification Certificate or Sworn Affidavit',
      'Professional Indemnity Insurance copy',
      'Company Registration Document (CIPC)'
    ],
    evaluationCriteria: [
      '80/20 preference point system (80 Price, 20 B-BBEE)',
      'Minimum functionality threshold: 70 points out of 100 to pass'
    ],
    capabilityMatch: [
      `NexMotion has delivered 3 successful projects in ${tenderInfo.category} during the last 24 months.`,
      `Our corporate BBBEE score is Level 1, which guarantees max preferential points.`
    ],
    fitScore: score,
    fitScoreBreakdown: {
      technical: Math.round(score * 0.95),
      compliance: 100,
      timeline: 80,
      budget: 85
    },
    risks: [
      `Penalties of 1% per day of delay on hardware delivery schedules.`,
      `Strict SLA compliance requiring on-site engineer dispatch within 2 hours in ${tenderInfo.province}.`
    ],
    recommendation: recommendations[0],
  };
}

// Manual Tender Creation (supports manual upload or link paste)
app.post('/api/tenders', async (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Viewers cannot create tenders.' });
  }

  const { title, link, source, municipality, province, category, budgetMin, budgetMax, deadline } = req.body;

  if (!title || !municipality || !province || !category) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const aiAnalysis = await performAIAnalysis({
      title,
      source: source || 'Manual Upload',
      municipality,
      province,
      category,
      budgetMin: Number(budgetMin) || 1000000,
      budgetMax: Number(budgetMax) || 3000000,
    });

    const newTender: Tender = {
      id: 'tender_' + Math.random().toString(36).substr(2, 9),
      title,
      link: link || '#',
      source: source || 'Manual Upload',
      municipality,
      province,
      category,
      budget: { min: Number(budgetMin) || 1000000, max: Number(budgetMax) || 3000000 },
      deadline: deadline || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
      datePosted: new Date().toISOString(),
      status: 'identified',
      assignedTo: [],
      comments: [],
      analysis: aiAnalysis,
      bid: {
        status: 'none',
        checklist: [],
        documents: [],
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    dbState.tenders.unshift(newTender);
    
    // Add record to analytics for Identified opportunities
    const currentMonth = new Date().toISOString().substring(0, 7); // YYYY-MM
    const monthlyAnal = dbState.analytics.find(a => a.id === currentMonth);
    if (monthlyAnal) {
      monthlyAnal.counts.opportunitiesIdentified += 1;
    }

    saveDb();
    res.json(newTender);
  } catch (err) {
    console.error('Error creating tender:', err);
    res.status(500).json({ error: 'Failed to create and analyze tender.' });
  }
});

// Trigger / Re-run AI Analysis
app.post('/api/tenders/:id/analyze', async (req, res) => {
  const { id } = req.params;
  const tender = dbState.tenders.find(t => t.id === id);
  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    const aiAnalysis = await performAIAnalysis({
      title: tender.title,
      source: tender.source,
      municipality: tender.municipality,
      province: tender.province,
      category: tender.category,
      budgetMin: tender.budget.min,
      budgetMax: tender.budget.max,
    });

    tender.analysis = aiAnalysis;
    tender.updatedAt = new Date().toISOString();
    saveDb();
    res.json(tender);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

// Update Tender Status (Kanban pipeline)
app.post('/api/tenders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Viewers cannot move tenders.' });
  }

  const oldStatus = tender.status;
  tender.status = status as TenderStatus;
  tender.updatedAt = new Date().toISOString();

  // If moving to 'preparing' and bid is empty, bootstrap the compliance checklist!
  if (status === 'preparing' && (!tender.bid || tender.bid.checklist.length === 0)) {
    // Generate 8-12 compliance checklist items based on AI compliant requirements!
    const items = [
      'SARS Tax Clearance pin verification',
      'B-BBEE level sworn affidavit',
      'Professional Indemnity Insurance copy',
      'Company Registration document (CIPC)',
      'Proposed Project Implementation methodology doc',
      'Qualified Engineer Resume & certifications',
      'POPIA Consent Compliance statement',
      'Detailed Financial Bid Pricing spreadsheet'
    ];

    tender.bid = {
      status: 'in_progress',
      checklist: items.map(item => {
        let linkedDocId: string | undefined = undefined;
        let completed = false;

        // Auto-match defaults for CEO if we have them in the vault!
        const categoryMap: Record<string, string> = {
          'SARS Tax Clearance': 'taxClearance',
          'B-BBEE': 'bbbee',
          'Professional Indemnity': 'insurance',
          'Company Registration': 'companyProfile',
          'POPIA': 'popiaDisclosure'
        };

        const matchingKey = Object.keys(categoryMap).find(k => item.toLowerCase().includes(k.toLowerCase()));
        if (matchingKey) {
          const cat = categoryMap[matchingKey];
          const defaultDocId = dbState.users.find(u => u.role === 'ceo')?.defaultDocumentIds[cat];
          if (defaultDocId) {
            linkedDocId = defaultDocId;
            completed = true;
          }
        }

        return {
          item,
          assignedTo: 'user_pm', // default assign to PM
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10),
          completed,
          linkedDocumentId: linkedDocId
        };
      }),
      documents: []
    };

    // Auto-populate documents if checklist items were linked
    tender.bid.checklist.forEach(cl => {
      if (cl.linkedDocumentId) {
        const doc = dbState.documents.find(d => d.id === cl.linkedDocumentId);
        if (doc) {
          tender.bid.documents.push({
            documentId: doc.id,
            category: doc.category,
            attachedAt: new Date().toISOString(),
            attachedBy: 'System (Default Auto-Attach)'
          });
        }
      }
    });
  }

  // Log activity in comments
  tender.comments.push({
    id: 'comment_' + Math.random().toString(36).substr(2, 9),
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    text: `Moved tender status from ${oldStatus.toUpperCase()} to ${status.toUpperCase()}`,
    createdAt: new Date().toISOString()
  });

  // Track in analytics
  const currentMonth = new Date().toISOString().substring(0, 7);
  const monthlyAnal = dbState.analytics.find(a => a.id === currentMonth);
  if (monthlyAnal) {
    if (status === 'shortlisted' && oldStatus !== 'shortlisted') {
      monthlyAnal.counts.shortlistedCount += 1;
    } else if (status === 'submitted' && oldStatus !== 'submitted') {
      monthlyAnal.counts.submittedCount += 1;
    } else if (status === 'won' && oldStatus !== 'won') {
      monthlyAnal.counts.wonCount += 1;
    } else if (status === 'lost' && oldStatus !== 'lost') {
      monthlyAnal.counts.lostCount += 1;
    }
  }

  saveDb();
  res.json(tender);
});

// Update Checklist Item
app.post('/api/tenders/:id/checklist/update', (req, res) => {
  const { id } = req.params;
  const { itemIndex, completed, assignedTo, dueDate } = req.body;
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Viewers cannot modify checklists.' });
  }

  const clItem = tender.bid.checklist[itemIndex];
  if (!clItem) {
    return res.status(404).json({ error: 'Checklist item not found' });
  }

  const oldAssignee = clItem.assignedTo;
  clItem.completed = completed !== undefined ? completed : clItem.completed;
  clItem.assignedTo = assignedTo !== undefined ? assignedTo : clItem.assignedTo;
  clItem.dueDate = dueDate !== undefined ? dueDate : clItem.dueDate;

  // Send assignment email alert if assignee changed
  if (assignedTo && assignedTo !== oldAssignee) {
    const assignedUser = dbState.users.find(u => u.id === assignedTo);
    if (assignedUser) {
      sendSimulatedEmail(
        assignedUser.email,
        `New Compliance Task Assigned: ${clItem.item}`,
        `Hi ${assignedUser.name},\n\nYou have been assigned the compliance checklist task "${clItem.item}" for the tender "${tender.title}".\n\nDue date: ${clItem.dueDate}\n\nPlease prepare and attach this document.`,
        'assignment'
      );
    }
  }

  // Recalculate status auto-change to "Ready for Submission" if all complete
  const allComplete = tender.bid.checklist.every(c => c.completed);
  if (allComplete && tender.status === 'preparing') {
    tender.comments.push({
      id: 'comment_' + Math.random().toString(36).substr(2, 9),
      userId: 'system',
      userName: 'NexMotion AI Bot',
      userRole: 'system',
      text: `All compliance checklist items are fully resolved. Tender status is ready for submission!`,
      createdAt: new Date().toISOString()
    });
  }

  tender.updatedAt = new Date().toISOString();
  saveDb();
  res.json(tender);
});

// Attach document from vault to checklist item (One-click Attach)
app.post('/api/tenders/:id/checklist/attach-doc', (req, res) => {
  const { id } = req.params;
  const { itemIndex, documentId } = req.body;
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const clItem = tender.bid.checklist[itemIndex];
  if (!clItem) {
    return res.status(404).json({ error: 'Checklist item not found' });
  }

  const doc = dbState.documents.find(d => d.id === documentId);
  if (!doc) {
    return res.status(404).json({ error: 'Document not found' });
  }

  clItem.linkedDocumentId = documentId;
  clItem.completed = true;

  // Track attachment
  if (!tender.bid.documents.some(d => d.documentId === documentId)) {
    tender.bid.documents.push({
      documentId: doc.id,
      category: doc.category,
      attachedAt: new Date().toISOString(),
      attachedBy: user.name
    });
  }

  // Link tender ID back inside the document
  if (!doc.linkedTenderIds.includes(id)) {
    doc.linkedTenderIds.push(id);
    doc.updatedAt = new Date().toISOString();
  }

  tender.updatedAt = new Date().toISOString();
  saveDb();
  res.json({ tender, document: doc });
});

// Mark Bid Submitted
app.post('/api/tenders/:id/submit', (req, res) => {
  const { id } = req.params;
  const { bidValue } = req.body;
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  tender.status = 'submitted';
  tender.bid.status = 'submitted';
  tender.bid.bidValue = Number(bidValue) || tender.budget.min;
  tender.bid.submittedAt = new Date().toISOString();
  tender.updatedAt = new Date().toISOString();

  tender.comments.push({
    id: 'comment_' + Math.random().toString(36).substr(2, 9),
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    text: `Submitted final bid with pricing scheduled at R${Number(bidValue).toLocaleString()}`,
    createdAt: new Date().toISOString()
  });

  // Log in analytics
  const currentMonth = new Date().toISOString().substring(0, 7);
  const monthlyAnal = dbState.analytics.find(a => a.id === currentMonth);
  if (monthlyAnal) {
    monthlyAnal.counts.submittedCount += 1;
    monthlyAnal.financials.totalValueSubmitted += Number(bidValue);
  }

  saveDb();
  res.json(tender);
});

// Comments
app.post('/api/tenders/:id/comments', (req, res) => {
  const { id } = req.params;
  const { text } = req.body;
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  if (!text) {
    return res.status(400).json({ error: 'Missing comment text' });
  }

  const user = getActiveUser();
  // Viewers can comment on tenders they are assigned to, check is handled above or inside
  if (user.role === 'viewer' && !tender.assignedTo.includes(user.id)) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const newComment: Comment = {
    id: 'comment_' + Math.random().toString(36).substr(2, 9),
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    text,
    createdAt: new Date().toISOString(),
  };

  tender.comments.push(newComment);
  tender.updatedAt = new Date().toISOString();
  saveDb();
  res.json(tender);
});

// Assignments (CEO/PM only)
app.post('/api/tenders/:id/assign', (req, res) => {
  const { id } = req.params;
  const { userIds } = req.body; // array of user IDs
  const tender = dbState.tenders.find(t => t.id === id);

  if (!tender) {
    return res.status(404).json({ error: 'Tender not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Viewers cannot manage assignments.' });
  }

  const oldAssignments = tender.assignedTo || [];
  tender.assignedTo = userIds || [];
  tender.updatedAt = new Date().toISOString();

  // Send assignment alert emails to newly assigned users
  const newlyAssigned = tender.assignedTo.filter(uid => !oldAssignments.includes(uid));
  newlyAssigned.forEach(uid => {
    const assignedUser = dbState.users.find(u => u.id === uid);
    if (assignedUser) {
      sendSimulatedEmail(
        assignedUser.email,
        `New Tender Assigned: ${tender.title}`,
        `Hi ${assignedUser.name},\n\nYou have been explicitly assigned to the team for government tender "${tender.title}".\n\nPlease review the AI Analysis and help coordinate compliance documents in the preparation stage.`,
        'assignment'
      );
    }
  });

  saveDb();
  res.json(tender);
});

// Tasks Endpoints
app.get('/api/tasks', (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    const filtered = dbState.tasks.filter(t => t.assignedTo === user.id);
    return res.json(filtered);
  }
  res.json(dbState.tasks);
});

app.post('/api/tasks/:id/toggle', (req, res) => {
  const { id } = req.params;
  const task = dbState.tasks.find(t => t.id === id);

  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer' && task.assignedTo !== user.id) {
    return res.status(403).json({ error: 'Access denied: You can only toggle your own tasks.' });
  }

  task.completed = !task.completed;
  task.completedAt = task.completed ? new Date().toISOString() : undefined;
  task.status = task.completed ? 'completed' : 'in_progress';

  // Sync back to tender checklist if linked
  const tender = dbState.tenders.find(t => t.id === task.tenderId);
  if (tender && tender.bid && tender.bid.checklist) {
    const checkItem = tender.bid.checklist.find(c => c.item === task.item);
    if (checkItem) {
      checkItem.completed = task.completed;
    }
  }

  saveDb();
  res.json(task);
});

// Document Library / Vault Endpoints
app.get('/api/documents', (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Document Library is CEO/PM only. Viewers can only access documents linked to their assigned tenders.' });
  }
  res.json(dbState.documents);
});

// Upload/Create a new compliance Document
app.post('/api/documents', (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Viewers cannot upload vault documents.' });
  }

  const { fileName, fileType, fileSizeBytes, category, scope, issueDate, expiryDate, fileContentBase64 } = req.body;

  if (!fileName || !category) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  // Create document
  const docId = 'doc_' + Math.random().toString(36).substr(2, 9);
  const newDoc: Document = {
    id: docId,
    ownerId: user.id,
    ownerName: user.name,
    orgId: 'org_nexmotion',
    fileName,
    storagePath: `/orgs/org_nexmotion/documents/${docId}/${fileName}`,
    fileType: fileType || 'pdf',
    fileSizeBytes: fileSizeBytes || 1024 * 150, // default 150KB
    category,
    scope: scope || 'reusable',
    linkedTenderIds: [],
    version: 1,
    issueDate,
    expiryDate,
    status: 'active',
    scanStatus: 'clean', // Simulate instant clean scan
    uploadedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    versions: [
      {
        version: 1,
        fileName,
        storagePath: `/orgs/org_nexmotion/documents/${docId}/${fileName}`,
        fileSizeBytes: fileSizeBytes || 1024 * 150,
        uploadedAt: new Date().toISOString(),
        uploadedBy: user.name,
      }
    ]
  };

  dbState.documents.push(newDoc);

  // If set as reusable, auto-link to defaults in the users record if they are the CEO or updating defaults
  if (scope === 'reusable' && user.role === 'ceo') {
    user.defaultDocumentIds[category] = docId;
  }

  saveDb();
  res.json(newDoc);
});

// Update/Add new version of document
app.post('/api/documents/:id/versions', (req, res) => {
  const { id } = req.params;
  const { fileName, fileSizeBytes, issueDate, expiryDate } = req.body;
  const doc = dbState.documents.find(d => d.id === id);

  if (!doc) {
    return res.status(404).json({ error: 'Document not found' });
  }

  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const nextVer = doc.version + 1;
  const newVer = {
    version: nextVer,
    fileName: fileName || doc.fileName,
    storagePath: `/orgs/org_nexmotion/documents/${doc.id}/v${nextVer}_${fileName || doc.fileName}`,
    fileSizeBytes: fileSizeBytes || doc.fileSizeBytes,
    uploadedAt: new Date().toISOString(),
    uploadedBy: user.name,
  };

  doc.version = nextVer;
  doc.fileName = fileName || doc.fileName;
  doc.fileSizeBytes = fileSizeBytes || doc.fileSizeBytes;
  doc.issueDate = issueDate || doc.issueDate;
  doc.expiryDate = expiryDate || doc.expiryDate;
  doc.status = 'active'; // Reset status to active if updated
  doc.updatedAt = new Date().toISOString();
  if (!doc.versions) {
    doc.versions = [];
  }
  doc.versions.push(newVer);

  saveDb();
  res.json(doc);
});

// Log Document Access
app.post('/api/documents/:id/log-access', (req, res) => {
  const { id } = req.params;
  const { action } = req.body; // 'view' or 'download'
  const doc = dbState.documents.find(d => d.id === id);

  if (!doc) {
    return res.status(404).json({ error: 'Document not found' });
  }

  const user = getActiveUser();

  const log: AccessLog = {
    id: 'log_' + Math.random().toString(36).substr(2, 9),
    documentId: doc.id,
    documentName: doc.fileName,
    viewedBy: `${user.name} (${user.role.toUpperCase()})`,
    viewedAt: new Date().toISOString(),
    action: action || 'view',
  };

  dbState.accessLogs.unshift(log);
  saveDb();
  res.json(log);
});

app.get('/api/documents/:id/logs', (req, res) => {
  const { id } = req.params;
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const logs = dbState.accessLogs.filter(l => l.documentId === id);
  res.json(logs);
});

// Team Management Invite
app.post('/api/settings/team/invite', (req, res) => {
  const user = getActiveUser();
  if (user.role !== 'ceo') {
    return res.status(403).json({ error: 'Access denied: Only CEOs can manage the team.' });
  }

  const { name, email, role } = req.body;
  if (!name || !email || !role) {
    return res.status(400).json({ error: 'Missing team member details' });
  }

  const userExists = dbState.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (userExists) {
    return res.status(400).json({ error: 'User with this email already exists' });
  }

  const newUser: User = {
    id: 'user_' + Math.random().toString(36).substr(2, 9),
    name,
    email,
    role,
    createdAt: new Date().toISOString(),
    defaultDocumentIds: {},
  };

  dbState.users.push(newUser);

  // Send simulated invite email
  sendSimulatedEmail(
    email,
    `Invitation to join NexMotion Technologies TMS`,
    `Hi ${name},\n\nYou have been invited by Calvin Costa (CEO) to join NexMotion Tender Management System with the role of [${role.toUpperCase()}].\n\nPlease sign in with your Google account using this email to gain automatic access.\n\nBest regards,\nNexMotion Admin`,
    'assignment'
  );

  saveDb();
  res.json(newUser);
});

// Get Outbox list of email alerts
app.get('/api/email-alerts', (req, res) => {
  res.json(dbState.emailAlerts);
});

// Run Scraper (Simulated Scrape + AI Analysis)
app.post('/api/tenders/scrape', async (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  console.log('Running daily South African Government Tender Scraper...');

  // Curated lists of newly discovered ICT Tenders in South Africa
  const scrapeCandidates = [
    {
      title: 'Limpopo Department of Transport: Supply & Installation of Advanced Traffic Management Software & ANPR Cameras',
      source: 'Limpopo Provincial Gazette',
      municipality: 'Polokwane Local Municipality',
      province: 'Limpopo',
      category: 'Software Development',
      budgetMin: 4500000,
      budgetMax: 6200000,
    },
    {
      title: 'Free State Treasury: Provision of Datacenter Co-location and Managed Backup Services',
      source: 'E-Tenders South Africa',
      municipality: 'Mangaung Metropolitan Municipality',
      province: 'Free State',
      category: 'Cloud Services',
      budgetMin: 9500000,
      budgetMax: 12000000,
    },
    {
      title: 'Gauteng Department of Human Settlements: Development of Municipal Portal Mobile Applications for Citizen Grievances',
      source: 'Gauteng Procurement Portal',
      municipality: 'City of Johannesburg Metropolitan Municipality',
      province: 'Gauteng',
      category: 'Software Development',
      budgetMin: 3200000,
      budgetMax: 4800000,
    },
    {
      title: 'Tzaneen Local Municipality: Fiber Optic WAN Core Infrastructure Upgrade for Town Offices',
      source: 'Tzaneen Muni Website',
      municipality: 'Tzaneen Local Municipality',
      province: 'Limpopo',
      category: 'Infrastructure',
      budgetMin: 6000000,
      budgetMax: 7500000,
    }
  ];

  // Pick one that is not already scraped
  let selected = scrapeCandidates.find(c => !dbState.tenders.some(t => t.title === c.title));

  if (!selected) {
    // If all are scraped, generate a random one
    const suffix = Math.floor(Math.random() * 1000);
    selected = {
      title: `Gauteng Department of Health: IT Technical Helpdesk Outsourcing Service - Batch #${suffix}`,
      source: 'E-Tenders South Africa',
      municipality: 'City of Tshwane Metropolitan Municipality',
      province: 'Gauteng',
      category: 'IT Consulting',
      budgetMin: 5000000,
      budgetMax: 6500000,
    };
  }

  try {
    const aiAnalysis = await performAIAnalysis({
      title: selected.title,
      source: selected.source,
      municipality: selected.municipality,
      province: selected.province,
      category: selected.category,
      budgetMin: selected.budgetMin,
      budgetMax: selected.budgetMax,
    });

    const newTender: Tender = {
      id: 'tender_' + Math.random().toString(36).substr(2, 9),
      title: selected.title,
      link: 'https://www.etenders.gov.za/tenders/scraped-' + Math.random().toString(36).substr(2, 5),
      source: selected.source,
      municipality: selected.municipality,
      province: selected.province,
      category: selected.category,
      budget: { min: selected.budgetMin, max: selected.budgetMax },
      deadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), // 10 days from now
      datePosted: new Date().toISOString(),
      status: 'identified',
      assignedTo: [],
      comments: [
        {
          id: 'bot_c',
          userId: 'system',
          userName: 'NexMotion Scraper',
          userRole: 'system',
          text: `Automatically scraped and ingested at 06:00 SAST from "${selected.source}". AI Analysis has been generated.`,
          createdAt: new Date().toISOString(),
        }
      ],
      analysis: aiAnalysis,
      bid: {
        status: 'none',
        checklist: [],
        documents: [],
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    dbState.tenders.unshift(newTender);

    // Track in analytics
    const currentMonth = new Date().toISOString().substring(0, 7);
    const monthlyAnal = dbState.analytics.find(a => a.id === currentMonth);
    if (monthlyAnal) {
      monthlyAnal.counts.opportunitiesIdentified += 1;
    }

    saveDb();
    res.json({ success: true, tender: newTender });
  } catch (err) {
    console.error('Scraper run error:', err);
    res.status(500).json({ error: 'Failed to complete scraper run.' });
  }
});

// Analytics Dashboard Endpoint
app.get('/api/analytics', (req, res) => {
  const user = getActiveUser();
  if (user.role === 'viewer') {
    return res.status(403).json({ error: 'Access denied: Analytics are CEO/PM only.' });
  }

  res.json(dbState.analytics);
});

// Vite Middleware & static serving setup

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
