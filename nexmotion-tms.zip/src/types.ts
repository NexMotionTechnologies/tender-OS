export type TenderStatus = 'identified' | 'shortlisted' | 'preparing' | 'submitted' | 'won' | 'lost';

export interface BudgetRange {
  min: number;
  max: number;
}

export interface AIAnalysis {
  extractedRequirements: string[];
  complianceNeeds: string[];
  evaluationCriteria: string[];
  capabilityMatch: string[];
  fitScore: number;
  fitScoreBreakdown: {
    technical: number; // 40%
    compliance: number; // 30%
    timeline: number; // 20%
    budget: number; // 10%
  };
  risks: string[];
  recommendation: 'Pursue' | 'Maybe' | 'Skip';
}

export interface BidChecklistItem {
  item: string;
  assignedTo: string; // user ID
  dueDate: string;
  completed: boolean;
  linkedDocumentId?: string;
}

export interface BidDocument {
  documentId: string;
  category: string;
  attachedAt: string;
  attachedBy: string; // user name/email
}

export interface Bid {
  status: string;
  checklist: BidChecklistItem[];
  documents: BidDocument[];
  bidValue?: number;
  submittedAt?: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  text: string;
  createdAt: string;
}

export interface Tender {
  id: string;
  title: string;
  link: string;
  source: string;
  municipality: string;
  province: string;
  category: string;
  budget: BudgetRange;
  deadline: string;
  datePosted: string;
  status: TenderStatus;
  analysis: AIAnalysis;
  bid: Bid;
  assignedTo: string[]; // user IDs
  comments: Comment[];
  createdAt: string;
  updatedAt: string;
}

export type TaskPriority = 'critical' | 'high' | 'medium' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'overdue';

export interface Task {
  id: string;
  tenderId: string;
  tenderTitle: string;
  item: string;
  assignedTo: string; // user ID
  dueDate: string;
  completed: boolean;
  completedAt?: string;
  priority: TaskPriority;
  status: TaskStatus;
  createdAt: string;
}

export type UserRole = 'ceo' | 'pm' | 'viewer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt: string;
  defaultDocumentIds: Record<string, string>; // category -> documentId
}

export type DocumentCategory =
  | 'taxClearance'
  | 'bbbee'
  | 'insurance'
  | 'companyProfile'
  | 'sla'
  | 'testimonial'
  | 'proposal'
  | 'financialBid'
  | 'popiaDisclosure'
  | 'other';

export type DocumentScope = 'reusable' | 'tenderSpecific';
export type DocumentStatus = 'active' | 'expired' | 'expiringSoon' | 'archived' | 'deleted';
export type ScanStatus = 'pending' | 'clean' | 'flagged';

export interface DocumentVersion {
  version: number;
  fileName: string;
  storagePath: string;
  fileSizeBytes: number;
  uploadedAt: string;
  uploadedBy: string;
}

export interface Document {
  id: string;
  ownerId: string;
  ownerName: string;
  orgId: string;
  fileName: string;
  storagePath: string;
  fileType: 'pdf' | 'docx' | 'jpg' | 'png';
  fileSizeBytes: number;
  category: DocumentCategory;
  scope: DocumentScope;
  linkedTenderIds: string[];
  version: number;
  previousVersionId?: string;
  versions?: DocumentVersion[];
  issueDate?: string;
  expiryDate?: string;
  status: DocumentStatus;
  scanStatus: ScanStatus;
  uploadedAt: string;
  updatedAt: string;
}

export interface AccessLog {
  id: string;
  documentId: string;
  documentName: string;
  viewedBy: string; // email or name
  viewedAt: string;
  action: 'view' | 'download';
}

export interface EmailAlert {
  id: string;
  to: string;
  subject: string;
  body: string;
  sentAt: string;
  type: 'deadline' | 'expiry' | 'assignment';
}

export interface MonthlyCount {
  opportunitiesIdentified: number;
  shortlistedCount: number;
  submittedCount: number;
  wonCount: number;
  lostCount: number;
}

export interface MonthlyFinancial {
  totalValueSubmitted: number;
  totalValueWon: number;
  averageDealSize: number;
}

export interface MonthlyRate {
  submissionRate: number; // submitted / shortlisted %
  winRate: number; // won / submitted %
  lossRate: number; // lost / submitted %
}

export interface MonthlyAnalytics {
  id: string; // YYYY-MM
  month: string;
  year: string;
  startDate: string;
  endDate: string;
  counts: MonthlyCount;
  financials: MonthlyFinancial;
  rates: MonthlyRate;
  byCategory: Record<string, number>;
  byMunicipality: Record<string, number>;
}
