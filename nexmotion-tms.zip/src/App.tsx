import React, { useState, useEffect } from 'react';
import { ApiStoreProvider, useApiStore } from './store';
import { IntroPage } from './components/IntroPage';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { PipelineView } from './components/PipelineView';
import { TendersQueueView } from './components/TendersQueueView';
import { TenderDetailView } from './components/TenderDetailView';
import { BidPrepareView } from './components/BidPrepareView';
import { DocumentLibraryView } from './components/DocumentLibraryView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';

function MainAppContent() {
  const { activeUser, isLoading, error, refreshAll, switchUser } = useApiStore();
  const [authFlow, setAuthFlow] = useState<'intro' | 'login' | 'signup'>('intro');
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedTenderId, setSelectedTenderId] = useState<string | null>(null);

  // Synchronise sub-views navigation
  const handleNavigate = (view: string, targetId?: string) => {
    if (view === 'tenders-new' && targetId) {
      setSelectedTenderId(targetId);
      setCurrentView('tender-detail');
    } else {
      if (targetId) {
        setSelectedTenderId(targetId);
      }
      setCurrentView(view);
    }
  };

  const handleLogout = async () => {
    localStorage.removeItem('nexmotion_user_id');
    // Reload page to return to unauthenticated landing page
    window.location.reload();
  };

  // Enforce role routing constraints in UI
  useEffect(() => {
    if (activeUser && activeUser.role === 'viewer') {
      if (['documents', 'analytics'].includes(currentView)) {
        setCurrentView('dashboard'); // Redirect to safety
      }
    }
  }, [currentView, activeUser]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white text-black flex flex-col items-center justify-center font-sans border-[12px] border-black">
        <div className="w-16 h-16 border-8 border-black border-t-amber-400 rounded-none animate-spin"></div>
        <p className="mt-6 text-sm font-mono font-black uppercase tracking-widest text-black">
          Syncing NexMotion Workspace...
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white text-black flex flex-col items-center justify-center font-sans p-6 text-center border-[12px] border-black">
        <div className="p-8 bg-white border-[3px] border-black rounded-none max-w-md shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <h2 className="text-lg font-black uppercase text-red-600 tracking-tight">Connection Offline</h2>
          <p className="text-xs text-black/80 font-mono mt-3 leading-relaxed">{error}</p>
          <button
            onClick={refreshAll}
            className="mt-6 px-6 py-2.5 bg-black hover:bg-neutral-900 text-white font-black text-xs uppercase tracking-wider transition border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
          >
            Retry Sync
          </button>
        </div>
      </div>
    );
  }

  // Unauthenticated landing page & login flow
  if (!activeUser) {
    if (authFlow === 'login') {
      return (
        <LoginPage
          initialTab="login"
          onBackToIntro={() => setAuthFlow('intro')}
          onLoginSuccess={() => {
            setAuthFlow('intro');
            setCurrentView('dashboard');
          }}
        />
      );
    }
    if (authFlow === 'signup') {
      return (
        <LoginPage
          initialTab="signup"
          onBackToIntro={() => setAuthFlow('intro')}
          onLoginSuccess={() => {
            setAuthFlow('intro');
            setCurrentView('dashboard');
          }}
        />
      );
    }
    return (
      <IntroPage
        onStartSignup={() => setAuthFlow('signup')}
        onStartLogin={() => setAuthFlow('login')}
      />
    );
  }

  // Authenticated Portal
  return (
    <div className="min-h-screen bg-white text-black flex font-sans overflow-hidden h-screen border-[12px] border-black select-none">
      
      {/* Persistent left sidebar */}
      <Sidebar
        activeUser={activeUser}
        currentView={currentView}
        onNavigate={(view) => handleNavigate(view)}
        onLogout={handleLogout}
      />

      {/* Main viewport */}
      <div className="flex-1 flex flex-col overflow-hidden">
        
        {/* Header bar at the top */}
        <Header onNavigate={(view) => handleNavigate(view)} />

        {/* Dynamic workspace viewport */}
        <main className="flex-1 overflow-hidden bg-gray-50">
          
          {currentView === 'dashboard' && (
            <DashboardView onNavigate={handleNavigate} />
          )}

          {currentView === 'pipeline' && (
            <PipelineView onNavigate={handleNavigate} />
          )}

          {currentView === 'tenders-new' && (
            <TendersQueueView onNavigate={handleNavigate} />
          )}

          {currentView === 'tender-detail' && selectedTenderId && (
            <TenderDetailView
              tenderId={selectedTenderId}
              onBack={() => setCurrentView('tenders-new')}
              onNavigateToPrepare={(id) => {
                setSelectedTenderId(id);
                setCurrentView('tender-prepare');
              }}
            />
          )}

          {currentView === 'tender-prepare' && selectedTenderId && (
            <BidPrepareView
              tenderId={selectedTenderId}
              onBack={() => setCurrentView('tender-detail')}
              onNavigateToDocs={() => setCurrentView('documents')}
            />
          )}

          {currentView === 'documents' && (
            <DocumentLibraryView />
          )}

          {currentView === 'analytics' && (
            <AnalyticsView />
          )}

          {currentView === 'settings' && (
            <SettingsView />
          )}

        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ApiStoreProvider>
      <MainAppContent />
    </ApiStoreProvider>
  );
}
