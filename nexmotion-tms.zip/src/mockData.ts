import { Tender, Task, User, Document, AccessLog, EmailAlert, MonthlyAnalytics } from './types';

export const MOCK_USERS: User[] = [
  {
    id: 'user_ceo',
    name: 'Calvin Costa',
    email: 'costacalvin0321@gmail.com',
    role: 'ceo',
    createdAt: '2026-01-15T08:00:00Z',
    defaultDocumentIds: {},
  },
  {
    id: 'user_pm',
    name: 'Sibusiso Khumalo',
    email: 'sibusiso@nexmotion.co.za',
    role: 'pm',
    createdAt: '2026-02-10T09:30:00Z',
    defaultDocumentIds: {},
  },
  {
    id: 'user_viewer',
    name: 'Thabo Molefe',
    email: 'thabo@nexmotion.co.za',
    role: 'viewer',
    createdAt: '2026-03-01T10:15:00Z',
    defaultDocumentIds: {},
  },
];

export const MOCK_DOCUMENTS: Document[] = [];

export const MOCK_TENDERS: Tender[] = [];

export const MOCK_TASKS: Task[] = [];

export const MOCK_ACCESS_LOGS: AccessLog[] = [];

export const MOCK_EMAIL_ALERTS: EmailAlert[] = [];

export const MOCK_ANALYTICS: MonthlyAnalytics[] = [
  {
    id: '2026-06',
    month: 'June',
    year: '2026',
    startDate: '2026-06-01',
    endDate: '2026-06-30',
    counts: {
      opportunitiesIdentified: 0,
      shortlistedCount: 0,
      submittedCount: 0,
      wonCount: 0,
      lostCount: 0,
    },
    financials: {
      totalValueSubmitted: 0,
      totalValueWon: 0,
      averageDealSize: 0,
    },
    rates: {
      submissionRate: 0,
      winRate: 0,
      lossRate: 0,
    },
    byCategory: {},
    byMunicipality: {},
  },
  {
    id: '2026-07',
    month: 'July',
    year: '2026',
    startDate: '2026-07-01',
    endDate: '2026-07-31',
    counts: {
      opportunitiesIdentified: 0,
      shortlistedCount: 0,
      submittedCount: 0,
      wonCount: 0,
      lostCount: 0,
    },
    financials: {
      totalValueSubmitted: 0,
      totalValueWon: 0,
      averageDealSize: 0,
    },
    rates: {
      submissionRate: 0,
      winRate: 0,
      lossRate: 0,
    },
    byCategory: {},
    byMunicipality: {},
  },
];
