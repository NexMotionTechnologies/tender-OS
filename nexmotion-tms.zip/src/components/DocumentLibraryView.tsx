import React, { useState } from 'react';
import { useApiStore } from '../store';
import { Document, DocumentVersion, AccessLog } from '../types';
import { FolderClosed, Plus, ShieldCheck, Download, Eye, RotateCw, History, FileText, ClipboardList, AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const DocumentLibraryView: React.FC = () => {
  const { documents, uploadDocument, uploadNewDocVersion, logDocAccess, getDocLogs, activeUser } = useApiStore();
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [expiryFilter, setExpiryFilter] = useState('All');

  // Modal / Detail States
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [activeLogs, setActiveLogs] = useState<AccessLog[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // New Document Upload State
  const [uploadForm, setUploadForm] = useState({
    fileName: '',
    category: 'taxClearance',
    expiryDate: '',
    scope: 'reusable' as 'reusable' | 'tenderSpecific',
  });

  // Version Replace State
  const [replaceFileName, setReplaceFileName] = useState('');
  const [showReplaceModal, setShowReplaceModal] = useState(false);

  // Drag and drop simulator
  const [dragActive, setDragActive] = useState(false);
  const [scannedFile, setScannedFile] = useState<{ name: string; size: number; type: string; status: 'clean' | 'scanning' | 'failed' | null }>({
    name: '',
    size: 0,
    type: '',
    status: null,
  });

  if (!activeUser || activeUser.role === 'viewer') {
    return (
      <div className="p-8 text-center max-w-md mx-auto bg-white border-4 border-black rounded-none shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] mt-16 font-sans text-black">
        <ShieldAlert className="w-12 h-12 text-black mx-auto mb-4 stroke-[2.5]" />
        <h2 className="text-lg font-black uppercase text-black">Access Restricted</h2>
        <p className="text-sm text-neutral-700 mt-2 leading-relaxed font-semibold">
          The Document Vault is reserved for Corporate Executives (CEO) and Project Managers (PM). 
          Please contact your administrator to request clearance.
        </p>
      </div>
    );
  }

  const categories = [
    { value: 'taxClearance', label: 'SARS Tax Clearance Pin' },
    { value: 'bbbee', label: 'B-BBEE Affidavit' },
    { value: 'coida', label: 'COIDA Letter of Good Standing' },
    { value: 'companyProfile', label: 'Company Profile Portfolio' },
    { value: 'auditedFinancials', label: 'Audited Financial Statements' },
    { value: 'referenceLetters', label: 'Reference Testimonial Letters' },
    { value: 'insurance', label: 'Professional Indemnity Insurance' },
  ];

  // Filters
  const filteredDocs = documents.filter(d => {
    const matchesCategory = categoryFilter === 'All' || d.category === categoryFilter;
    let matchesExpiry = true;
    if (expiryFilter === 'Expiring') {
      matchesExpiry = d.status === 'expiringSoon';
    } else if (expiryFilter === 'Expired') {
      matchesExpiry = d.status === 'expired';
    }
    return matchesCategory && matchesExpiry;
  });

  // Drag & drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      await triggerSimulatedScan(file);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      await triggerSimulatedScan(file);
    }
  };

  const triggerSimulatedScan = async (file: File) => {
    // Client-side validations
    const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'];
    const maxBytes = 15 * 1024 * 1024; // 15MB

    if (!allowedTypes.includes(file.type)) {
      alert('Disallowed format! NexMotion Vault only accepts PDF, DOCX, JPG, and PNG files.');
      return;
    }
    if (file.size > maxBytes) {
      alert('File too large! Max file size limit is 15MB.');
      return;
    }

    setScannedFile({
      name: file.name,
      size: Math.round(file.size / 1024 / 1024 * 100) / 100,
      type: file.type,
      status: 'scanning'
    });

    // Simulate network virus & malware scan
    await new Promise(resolve => setTimeout(resolve, 1500));

    setScannedFile(prev => ({ ...prev, status: 'clean' }));
    setUploadForm(prev => ({ ...prev, fileName: file.name }));
    setReplaceFileName(file.name);
  };

  const handleCreateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadForm.fileName) return;

    setIsUploading(true);
    try {
      await uploadDocument({
        ...uploadForm,
        fileUrl: `/vault/storage/${Date.now()}_${uploadForm.fileName}`,
        issueDate: new Date().toISOString().split('T')[0],
      });
      setShowUploadModal(false);
      resetScanner();
    } catch (err) {
      console.error(err);
      alert('Document upload failed.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleReplaceVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoc || !replaceFileName) return;

    setIsUploading(true);
    try {
      await uploadNewDocVersion(selectedDoc.id, {
        fileName: replaceFileName,
        fileUrl: `/vault/storage/${Date.now()}_${replaceFileName}`,
      });
      setShowReplaceModal(false);
      setSelectedDoc(null);
      resetScanner();
    } catch (err) {
      console.error(err);
      alert('Replacing document version failed.');
    } finally {
      setIsUploading(false);
    }
  };

  const resetScanner = () => {
    setScannedFile({ name: '', size: 0, type: '', status: null });
    setReplaceFileName('');
  };

  const handleDownload = async (doc: Document) => {
    // Log Download action
    await logDocAccess(doc.id, 'download');
    // Generate simulated 15-minute expiration Signed URL alert
    alert(`Secure download initiated via AWS S3 Signed URL.\n\nFile: ${doc.fileName}\nValidity: 15 Minutes (Temporary Access Token)\nOwner IP logged: 127.0.0.1`);
  };

  const handleViewLogs = async (doc: Document) => {
    setSelectedDoc(doc);
    try {
      const logs = await getDocLogs(doc.id);
      setActiveLogs(logs);
      setShowLogsModal(true);
    } catch (err) {
      console.error(err);
      alert('Failed to retrieve security access logs.');
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-hidden max-w-7xl mx-auto w-full font-sans text-black">
      
      {/* Top Header */}
      <div className="shrink-0 flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-black flex items-center gap-2 uppercase">
            <FolderClosed className="w-6 h-6 text-black stroke-[2.5]" /> Compliance Vault (Document Library)
          </h1>
          <p className="text-xs font-bold text-neutral-600 mt-1 uppercase">
            Maintain pre-approved SARS, B-BBEE, and insurance certificates for instant one-click assembly.
          </p>
        </div>

        <button
          onClick={() => {
            resetScanner();
            setShowUploadModal(true);
          }}
          className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black text-xs font-black uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1.5 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] self-start md:self-center"
        >
          <Plus className="w-4.5 h-4.5 stroke-[2.5]" /> Upload Vault Asset
        </button>
      </div>

      {/* Filter Row */}
      <div className="shrink-0 bg-white border-[3px] border-black p-4 rounded-none flex flex-col md:flex-row gap-4 items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          {/* Category selection */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none"
          >
            <option value="All">All Categories</option>
            {categories.map(c => (
              <option key={c.value} value={c.value}>{c.label.toUpperCase()}</option>
            ))}
          </select>

          {/* Expiry selection */}
          <select
            value={expiryFilter}
            onChange={e => setExpiryFilter(e.target.value)}
            className="px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Expiring">Expiring Soon</option>
            <option value="Expired">Expired</option>
          </select>
        </div>

        <div className="text-xs text-neutral-600 font-black uppercase flex items-center gap-1.5 self-start md:self-center">
          <ShieldCheck className="w-4 h-4 text-emerald-600 stroke-[2.5]" /> Fully Encrypted POPIA Library
        </div>
      </div>

      {/* Document vault grid/table */}
      <div className="flex-1 bg-white border-[3px] border-black rounded-none overflow-hidden flex flex-col min-h-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
        <div className="flex-1 overflow-y-auto min-h-0">
          {filteredDocs.length > 0 ? (
            <div className="divide-y-2 divide-black">
              
              {/* Header */}
              <div className="hidden md:flex items-center px-6 py-3 bg-gray-100 text-[10px] font-black text-black uppercase tracking-wider font-mono border-b-2 border-black">
                <div className="w-[30%]">Filename / Category</div>
                <div className="w-[15%]">Type</div>
                <div className="w-[10%]">Version</div>
                <div className="w-[15%]">Uploader</div>
                <div className="w-[15%]">Expiry Date</div>
                <div className="w-[15%] text-right">Actions</div>
              </div>

              {/* Rows */}
              {filteredDocs.map(doc => {
                const isExpired = doc.status === 'expired';
                const isExpiring = doc.status === 'expiringSoon';

                return (
                  <div
                    key={doc.id}
                    className="flex flex-col md:flex-row md:items-center px-6 py-4 hover:bg-neutral-50 transition gap-3"
                  >
                    {/* Filename & Category */}
                    <div className="w-full md:w-[30%] space-y-1">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-black shrink-0 stroke-[2.5]" />
                        <h3 className="font-black text-xs text-black truncate block max-w-[85%] uppercase">
                          {doc.fileName}
                        </h3>
                      </div>
                      <span className="text-[10px] text-neutral-500 font-mono font-bold block uppercase">
                        {categories.find(c => c.value === doc.category)?.label.toUpperCase() || doc.category.toUpperCase()}
                      </span>
                    </div>

                    {/* Scope / Type */}
                    <div className="w-full md:w-[15%] text-xs text-black font-bold uppercase">
                      <span>{doc.scope.replace(/([A-Z])/g, ' $1').toUpperCase()}</span>
                    </div>

                    {/* Version */}
                    <div className="w-full md:w-[10%] text-xs text-black font-mono font-black uppercase">
                      v{doc.version}
                    </div>

                    {/* Uploaded By */}
                    <div className="w-full md:w-[15%] text-xs text-black font-bold uppercase">
                      {doc.uploadedBy.toUpperCase()}
                    </div>

                    {/* Expiry Date */}
                    <div className="w-full md:w-[15%] text-xs">
                      {doc.expiryDate ? (
                        <div className="space-y-1">
                          <span className="text-black font-black block">{new Date(doc.expiryDate).toLocaleDateString('en-ZA')}</span>
                          {isExpired ? (
                            <span className="text-[9px] font-black font-mono text-red-700 bg-red-100 border border-red-400 px-1.5 py-0.5 rounded-none uppercase inline-block">Expired</span>
                          ) : isExpiring ? (
                            <span className="text-[9px] font-black font-mono text-amber-700 bg-amber-100 border border-amber-400 px-1.5 py-0.5 rounded-none uppercase inline-block">Expiring soon</span>
                          ) : (
                            <span className="text-[9px] font-black font-mono text-emerald-700 bg-emerald-100 border border-emerald-400 px-1.5 py-0.5 rounded-none uppercase inline-block">Active</span>
                          )}
                        </div>
                      ) : (
                        <span className="text-neutral-500 font-bold uppercase">Infinite scope</span>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="w-full md:w-[15%] flex md:justify-end items-center gap-2">
                      <button
                        onClick={() => handleDownload(doc)}
                        className="p-1.5 border-2 border-black bg-white hover:bg-gray-100 text-black rounded-none transition shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[0.5px] active:translate-y-[0.5px]"
                        title="Download secure copy"
                      >
                        <Download className="w-4 h-4 stroke-[2.5]" />
                      </button>

                      <button
                        onClick={() => {
                          setSelectedDoc(doc);
                          resetScanner();
                          setShowReplaceModal(true);
                        }}
                        className="p-1.5 border-2 border-black bg-white hover:bg-gray-100 text-black rounded-none transition shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[0.5px] active:translate-y-[0.5px]"
                        title="Upload replacement version"
                      >
                        <RotateCw className="w-4 h-4 stroke-[2.5]" />
                      </button>

                      <button
                        onClick={() => handleViewLogs(doc)}
                        className="p-1.5 border-2 border-black bg-white hover:bg-gray-100 text-black rounded-none transition shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[0.5px] active:translate-y-[0.5px]"
                        title="View audit trail logs"
                      >
                        <History className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    </div>

                  </div>
                );
              })}

            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-neutral-500 font-bold uppercase text-xs py-16">
              No matching documents inside the compliance vault.
            </div>
          )}
        </div>
      </div>

      {/* Upload Document Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-md bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 text-black">
            
            <div className="pb-3 border-b-2 border-black flex items-center justify-between">
              <h3 className="font-black text-base text-black uppercase tracking-tight">Upload Compliance Document</h3>
              <button onClick={() => setShowUploadModal(false)} className="text-black hover:bg-gray-100 px-2 py-1 border-2 border-black text-xs font-black uppercase rounded-none">
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-4 mt-4">
              
              {/* Drag and Drop Container */}
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`p-6 border-2 border-dashed rounded-none flex flex-col items-center text-center cursor-pointer transition ${
                  dragActive ? 'border-amber-400 bg-amber-50' : 'border-black bg-neutral-50'
                }`}
              >
                <input
                  type="file"
                  id="file-upload"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <label htmlFor="file-upload" className="cursor-pointer space-y-2">
                  <FolderClosed className="w-8 h-8 text-black mx-auto stroke-[2.5]" />
                  <span className="text-xs font-black text-black uppercase block">
                    Drag & Drop or Click to browse
                  </span>
                  <span className="text-[10px] text-neutral-500 font-bold uppercase block">
                    Supports PDF, DOCX, JPG, PNG up to 15MB
                  </span>
                </label>
              </div>

              {/* Scan Status block */}
              {scannedFile.name && (
                <div className="p-3 bg-white rounded-none border-2 border-black text-xs flex items-center justify-between font-bold">
                  <div>
                    <span className="font-black text-black block truncate max-w-[200px] uppercase">{scannedFile.name}</span>
                    <span className="text-[10px] text-neutral-500 font-mono font-black">{scannedFile.size}MB</span>
                  </div>
                  {scannedFile.status === 'scanning' ? (
                    <span className="text-amber-600 font-black text-[10px] uppercase tracking-wider animate-pulse flex items-center gap-1">
                      <RotateCw className="w-3.5 h-3.5 animate-spin stroke-[2.5]" /> Scanning...
                    </span>
                  ) : (
                    <span className="text-emerald-600 font-black text-[10px] uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" /> Clean / Pre-Approved
                    </span>
                  )}
                </div>
              )}

              {/* Form Category selection */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Document Category
                </label>
                <select
                  value={uploadForm.category}
                  onChange={e => setUploadForm({ ...uploadForm, category: e.target.value })}
                  className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none"
                >
                  {categories.map(c => (
                    <option key={c.value} value={c.value}>{c.label.toUpperCase()}</option>
                  ))}
                </select>
              </div>

              {/* Form Expiry */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Expiry Date (If applicable)
                </label>
                <input
                  type="date"
                  value={uploadForm.expiryDate}
                  onChange={e => setUploadForm({ ...uploadForm, expiryDate: e.target.value })}
                  className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none"
                />
              </div>

              {/* Scope Selection */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Sourcing Scope
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setUploadForm({ ...uploadForm, scope: 'reusable' })}
                    className={`p-2 border-2 text-xs rounded-none font-black uppercase tracking-wider transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] ${
                      uploadForm.scope === 'reusable'
                        ? 'bg-amber-400 border-black text-black'
                        : 'bg-white border-black text-neutral-400'
                    }`}
                  >
                    Reusable (Global Vault)
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadForm({ ...uploadForm, scope: 'tenderSpecific' })}
                    className={`p-2 border-2 text-xs rounded-none font-black uppercase tracking-wider transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] ${
                      uploadForm.scope === 'tenderSpecific'
                        ? 'bg-amber-400 border-black text-black'
                        : 'bg-white border-black text-neutral-400'
                    }`}
                  >
                    Tender-Specific Card
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t-2 border-black flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-white hover:bg-gray-100 text-xs font-black uppercase border-2 border-black rounded-none transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading || scannedFile.status !== 'clean'}
                  className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-55 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  {isUploading ? 'Uploading...' : 'Save Asset'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Replace Document Version Modal */}
      {showReplaceModal && selectedDoc && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-md bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 text-black">
            
            <div className="pb-3 border-b-2 border-black flex items-center justify-between">
              <h3 className="font-black text-base text-black uppercase tracking-tight">Upload New Version: {selectedDoc.fileName.toUpperCase()}</h3>
              <button onClick={() => setShowReplaceModal(false)} className="text-black hover:bg-gray-100 px-2 py-1 border-2 border-black text-xs font-black uppercase rounded-none">
                Cancel
              </button>
            </div>

            <form onSubmit={handleReplaceVersion} className="space-y-4 mt-4">
              
              <div className="p-3.5 bg-amber-50 rounded-none border-2 border-black text-xs text-black font-semibold leading-normal shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] uppercase">
                Note: Uploading a replacement file automatically increments the document version 
                (currently v{selectedDoc.version}) and maintains all past history logs. Re-evaluation is automatically queued.
              </div>

              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className="p-6 border-2 border-dashed border-black rounded-none flex flex-col items-center text-center cursor-pointer bg-neutral-50 hover:bg-amber-50/20"
              >
                <input
                  type="file"
                  id="replace-upload"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <label htmlFor="replace-upload" className="cursor-pointer space-y-2">
                  <RotateCw className="w-8 h-8 text-black mx-auto stroke-[2.5]" />
                  <span className="text-xs font-black text-black uppercase block">Click to select newer document copy</span>
                </label>
              </div>

              {scannedFile.name && (
                <div className="p-3 bg-white rounded-none border-2 border-black text-xs flex items-center justify-between font-bold">
                  <span className="font-black text-black truncate max-w-[200px] uppercase">{scannedFile.name}</span>
                  <span className="text-emerald-600 font-black text-[10px] uppercase">Clean Scan</span>
                </div>
              )}

              <div className="pt-4 border-t-2 border-black flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowReplaceModal(false)}
                  className="px-4 py-2 bg-white hover:bg-gray-100 text-xs font-black uppercase border-2 border-black rounded-none transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading || scannedFile.status !== 'clean'}
                  className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] disabled:opacity-55 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  {isUploading ? 'Uploading...' : 'Publish Version v' + (selectedDoc.version + 1)}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Security Logs Modal */}
      {showLogsModal && selectedDoc && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-lg bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 text-black">
            
            <div className="pb-3 border-b-2 border-black flex items-center justify-between">
              <h3 className="font-black text-base text-black uppercase tracking-tight">Compliance Access Log Audit</h3>
              <button onClick={() => setShowLogsModal(false)} className="text-black hover:bg-gray-100 px-2 py-1 border-2 border-black text-xs font-black uppercase rounded-none">
                Close
              </button>
            </div>

            <div className="mt-4 space-y-3.5 max-h-80 overflow-y-auto pr-1">
              {activeLogs.length > 0 ? (
                activeLogs.map(log => (
                  <div key={log.id} className="p-3.5 bg-white border-2 border-black rounded-none text-xs space-y-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-black uppercase tracking-wider text-[9px] px-2 py-0.5 rounded-none font-mono bg-gray-100 border-2 border-black">
                        {log.action.toUpperCase()}
                      </span>
                      <span className="text-neutral-500 font-mono font-bold text-[10px]">
                        {new Date(log.timestamp).toLocaleString('en-ZA')}
                      </span>
                    </div>
                    <div className="text-black font-bold uppercase text-[10px]">
                      User: <strong className="text-black font-black">{log.userName}</strong> • Role: <span className="text-[10px] font-mono text-neutral-500 font-black">{log.userRole.toUpperCase()}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-neutral-500 font-bold uppercase italic py-8 text-center">No access audits recorded on this vault asset.</p>
              )}
            </div>

            <div className="pt-4 border-t-2 border-black flex justify-end">
              <button
                onClick={() => setShowLogsModal(false)}
                className="px-4 py-2 bg-white hover:bg-gray-100 text-xs font-black uppercase border-2 border-black rounded-none transition"
              >
                Close Audit Trail
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
