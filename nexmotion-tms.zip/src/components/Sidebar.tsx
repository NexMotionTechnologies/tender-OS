import React from 'react';
import { LayoutDashboard, Kanban, FileText, FolderClosed, BarChart2, Settings, LogOut, ShieldCheck } from 'lucide-react';
import { User } from '../types';

interface SidebarProps {
  activeUser: User | null;
  currentView: string;
  onNavigate: (view: string) => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeUser, currentView, onNavigate, onLogout }) => {
  if (!activeUser) return null;

  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard, roles: ['ceo', 'pm', 'viewer'] },
    { id: 'pipeline', name: 'Kanban Pipeline', icon: Kanban, roles: ['ceo', 'pm', 'viewer'] },
    { id: 'tenders-new', name: 'New Tenders Queue', icon: FileText, roles: ['ceo', 'pm', 'viewer'] },
    { id: 'documents', name: 'Document Vault', icon: FolderClosed, roles: ['ceo', 'pm'] }, // CEO/PM only
    { id: 'analytics', name: 'Analytics', icon: BarChart2, roles: ['ceo', 'pm'] }, // CEO/PM only
    { id: 'settings', name: 'Settings', icon: Settings, roles: ['ceo', 'pm', 'viewer'] },
  ];

  return (
    <aside className="w-64 bg-gray-50 border-r-[3px] border-black flex flex-col justify-between shrink-0 font-sans select-none h-full">
      {/* Top Logo */}
      <div>
        <div className="h-16 flex items-center px-6 border-b-[3px] border-black space-x-3 bg-white">
          <div className="w-8 h-8 rounded-none border-2 border-black bg-amber-400 flex items-center justify-center font-black text-black text-lg">
            N
          </div>
          <span className="font-black tracking-tighter text-lg text-black uppercase">
            NexMotion <span className="text-amber-500 font-mono text-xs font-black">TMS</span>
          </span>
        </div>

        {/* Navigation Items */}
        <nav className="p-4 space-y-2">
          {menuItems.map(item => {
            const hasAccess = item.roles.includes(activeUser.role);
            if (!hasAccess) return null;

            const Icon = item.icon;
            const isActive = currentView === item.id || (item.id === 'tenders-new' && currentView === 'tender-detail');

            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-none text-xs font-black uppercase tracking-wider transition-all duration-100 ${
                  isActive
                    ? 'bg-black text-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                    : 'text-black hover:bg-black/5 hover:border-black/20 border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-black'}`} />
                <span>{item.name}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Profile and Logout */}
      <div className="p-4 border-t-[3px] border-black space-y-4 bg-white">
        {/* Compliance Guard Display */}
        <div className="bg-white p-3 rounded-none border-2 border-black flex items-center space-x-2.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="text-[11px] text-black leading-tight">
            <span className="font-black uppercase tracking-tight text-black block">POPIA GUARD</span>
            ENCRYPTED NODE
          </div>
        </div>

        {/* Logout button */}
        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center space-x-3 px-4 py-2.5 text-black hover:bg-red-500 hover:text-white rounded-none text-xs font-black uppercase tracking-wider transition border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
        >
          <LogOut className="w-4 h-4" />
          <span>Exit Portal</span>
        </button>
      </div>
    </aside>
  );
};
