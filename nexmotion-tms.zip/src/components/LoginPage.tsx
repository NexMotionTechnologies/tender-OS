import React, { useState } from 'react';
import { useApiStore } from '../store';
import { ShieldAlert, ArrowLeft, KeyRound, Mail, UserPlus, LogIn, ShieldCheck } from 'lucide-react';

interface LoginPageProps {
  initialTab?: 'login' | 'signup';
  onBackToIntro: () => void;
  onLoginSuccess: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ initialTab = 'login', onBackToIntro, onLoginSuccess }) => {
  const { allUsers, switchUser, signUp, loginByEmail } = useApiStore();
  const [activeTab, setActiveTab] = useState<'login' | 'signup'>(initialTab);
  const [selectedUserId, setSelectedUserId] = useState('user_ceo');
  const [customEmail, setCustomEmail] = useState('');
  const [customPin, setCustomPin] = useState('');
  
  // Workspace Choice states for corporate accounts
  const [showWorkspaceChoice, setShowWorkspaceChoice] = useState(false);
  const [pendingEmail, setPendingEmail] = useState('');
  const [pendingPin, setPendingPin] = useState('');

  // Signup State fields
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupRole, setSignupRole] = useState<'ceo' | 'pm' | 'viewer'>('ceo');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleOAuthSignIn = async (userId: string) => {
    setIsLoggingIn(true);
    setErrorMsg(null);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      await switchUser(userId);
      onLoginSuccess();
    } catch (err) {
      setErrorMsg('Google Sign-In failed. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleCustomEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail) return;

    const emailLower = customEmail.toLowerCase();
    const isNexMotion = emailLower.includes('nexmotion') || emailLower.endsWith('.co.za');
    if (isNexMotion && !customPin) {
      setErrorMsg('A security PIN is required for NexMotion corporate email addresses.');
      return;
    }

    const isCorp = isNexMotion || emailLower === 'costacalvin0321@gmail.com';

    if (isCorp) {
      // Prompt selection options first
      setPendingEmail(customEmail);
      setPendingPin(customPin);
      setShowWorkspaceChoice(true);
      setErrorMsg(null);
    } else {
      setIsLoggingIn(true);
      setErrorMsg(null);
      try {
        await new Promise(resolve => setTimeout(resolve, 600));
        await loginByEmail(customEmail, customPin);
        onLoginSuccess();
      } catch (err: any) {
        setErrorMsg(err.message || 'An error occurred during authentication.');
      } finally {
        setIsLoggingIn(false);
      }
    }
  };

  const handleWorkspaceChoice = async (role: 'ceo' | 'viewer') => {
    setIsLoggingIn(true);
    setErrorMsg(null);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      await loginByEmail(pendingEmail, pendingPin, role);
      setShowWorkspaceChoice(false);
      onLoginSuccess();
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred during authentication.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupName || !signupEmail) {
      setErrorMsg('Please enter both your name and email address.');
      return;
    }

    setIsLoggingIn(true);
    setErrorMsg(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      await signUp({
        name: signupName,
        email: signupEmail,
        role: signupRole,
      });
      onLoginSuccess();
    } catch (err: any) {
      setErrorMsg(err.message || 'Account creation failed. That email address might already be registered.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  if (showWorkspaceChoice) {
    return (
      <div className="min-h-screen bg-neutral-100 text-black flex flex-col justify-between font-sans">
        {/* Header */}
        <header className="max-w-7xl mx-auto px-6 w-full py-6 flex items-center justify-between">
          <button
            onClick={() => setShowWorkspaceChoice(false)}
            className="flex items-center gap-2 text-xs font-black text-black hover:bg-white border-2 border-black px-3.5 py-2 rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] bg-neutral-50 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] uppercase tracking-wider"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" /> Back to Login
          </button>
          <span className="text-xs font-black uppercase tracking-wider text-black bg-white px-2.5 py-1.5 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            Workspace Selector
          </span>
        </header>

        {/* Workspace selector card */}
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-8 relative text-black">
            
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-none bg-amber-400 border-[3px] border-black flex items-center justify-center font-black text-black text-2xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] mx-auto mb-3">
                C
              </div>
              <h2 className="text-xl font-black text-black tracking-tight uppercase">Corporate Identity Verified</h2>
              <p className="text-[10px] font-black text-neutral-500 mt-0.5 uppercase tracking-wider">
                Select your workspace landing interface
              </p>
            </div>

            {errorMsg && (
              <div className="mb-6 p-4 bg-red-100 border-2 border-black rounded-none flex items-start gap-3 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5 stroke-[2.5]" />
                <div className="text-[10px] text-red-950 leading-relaxed font-bold uppercase">
                  {errorMsg}
                </div>
              </div>
            )}

            <div className="space-y-4">
              
              {/* Option A: Admin Side */}
              <button
                onClick={() => handleWorkspaceChoice('ceo')}
                disabled={isLoggingIn}
                className="w-full text-left p-5 border-3 border-black bg-amber-50 hover:bg-amber-100 transition rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] flex items-start gap-4 active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-50"
              >
                <div className="p-2 bg-amber-400 border-2 border-black rounded-none shrink-0 mt-1">
                  <ShieldCheck className="w-6 h-6 text-black stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase text-black tracking-tight flex items-center gap-2">
                    Go to Admin Workspace 
                    <span className="text-[8px] bg-black text-white px-1.5 py-0.5 font-mono">FULL ACCESS</span>
                  </h3>
                  <p className="text-[10px] text-neutral-800 font-bold mt-1 leading-normal uppercase">
                    Access high-level bid compilations, full analytics dashboard, Document Vault (SARS compliance & B-BBEE letters), activity security logs, and team management tools.
                  </p>
                </div>
              </button>

              {/* Option B: Standard Customer Front-end */}
              <button
                onClick={() => handleWorkspaceChoice('viewer')}
                disabled={isLoggingIn}
                className="w-full text-left p-5 border-3 border-black bg-white hover:bg-neutral-50 transition rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] flex items-start gap-4 active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-50"
              >
                <div className="p-2 bg-neutral-200 border-2 border-black rounded-none shrink-0 mt-1">
                  <LogIn className="w-6 h-6 text-black stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase text-black tracking-tight flex items-center gap-2">
                    Go to Customer Front-end
                    <span className="text-[8px] bg-neutral-200 border border-black text-black px-1.5 py-0.5 font-mono">READ-ONLY</span>
                  </h3>
                  <p className="text-[10px] text-neutral-500 font-bold mt-1 leading-normal uppercase">
                    Open standard client dashboard showing identified sourcing opportunities, Kanban pipeline stages, and active task items in high-compliance read-only mode.
                  </p>
                </div>
              </button>

            </div>

            {isLoggingIn && (
              <div className="mt-6 flex items-center justify-center gap-2 text-xs font-mono font-black uppercase tracking-wider text-black">
                <div className="w-4 h-4 border-2 border-black border-t-amber-400 rounded-full animate-spin"></div>
                <span>Securing workspace connection...</span>
              </div>
            )}

            <p className="text-center text-[9px] font-bold text-neutral-400 uppercase tracking-wider mt-6">
              Authenticated session: {pendingEmail}
            </p>

          </div>
        </main>

        {/* Footer */}
        <footer className="max-w-7xl mx-auto px-6 w-full py-6 text-center text-[10px] font-bold text-neutral-500 uppercase tracking-wider">
          NexMotion TMS v2.0 • Secured under South African POPIA Regulations • Private Enterprise Asset
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 text-black flex flex-col justify-between font-sans">
      
      {/* Header */}
      <header className="max-w-7xl mx-auto px-6 w-full py-6 flex items-center justify-between">
        <button
          onClick={onBackToIntro}
          className="flex items-center gap-2 text-xs font-black text-black hover:bg-white border-2 border-black px-3.5 py-2 rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] bg-neutral-50 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] uppercase tracking-wider"
        >
          <ArrowLeft className="w-4 h-4 stroke-[2.5]" /> Back to Welcome
        </button>
        <span className="text-xs font-black uppercase tracking-wider text-black bg-white px-2.5 py-1.5 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          Auth & Register Portal
        </span>
      </header>

      {/* Main Form Container */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-8 relative text-black">
          
          {/* Logo Branding */}
          <div className="text-center mb-6">
            <div className="w-12 h-12 rounded-none bg-amber-400 border-[3px] border-black flex items-center justify-center font-black text-black text-2xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] mx-auto mb-3">
              N
            </div>
            <h2 className="text-2xl font-black text-black tracking-tight uppercase">NexMotion TMS</h2>
            <p className="text-[10px] font-black text-neutral-500 mt-0.5 uppercase tracking-wider">
              Tender Management workspace
            </p>
          </div>

          {/* Neo-brutalist Tab Toggles */}
          <div className="grid grid-cols-2 gap-2 mb-6 border-b-2 border-black pb-4">
            <button
              type="button"
              onClick={() => {
                setActiveTab('login');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-black uppercase tracking-wider border-2 border-black transition rounded-none ${
                activeTab === 'login'
                  ? 'bg-amber-400 text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  : 'bg-white hover:bg-neutral-50 text-neutral-500'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5">
                <LogIn className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Log In</span>
              </div>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('signup');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-black uppercase tracking-wider border-2 border-black transition rounded-none ${
                activeTab === 'signup'
                  ? 'bg-amber-400 text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
                  : 'bg-white hover:bg-neutral-50 text-neutral-500'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5">
                <UserPlus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Sign Up</span>
              </div>
            </button>
          </div>

          {/* Error Message Dialog */}
          {errorMsg && (
            <div className="mb-6 p-4 bg-red-100 border-2 border-black rounded-none flex items-start gap-3 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5 stroke-[2.5]" />
              <div className="text-[10px] text-red-950 leading-relaxed font-bold uppercase">
                <span className="font-black text-red-600 block">Verification Alerted</span>
                {errorMsg}
              </div>
            </div>
          )}

          {/* Form switch content */}
          {activeTab === 'login' ? (
            <div className="space-y-6">
              
              {/* Profile Selector */}
              <div className="bg-neutral-50 p-4 rounded-none border-2 border-black">
                <span className="text-[9px] font-black text-neutral-500 uppercase tracking-wider block mb-2.5 font-mono">
                  [Google Auth Switcher] Pick profile
                </span>
                
                <div className="space-y-2 mb-4">
                  {allUsers.map(u => (
                    <button
                      key={u.id}
                      onClick={() => setSelectedUserId(u.id)}
                      className={`w-full text-left p-2.5 rounded-none flex items-center justify-between border-2 transition ${
                        selectedUserId === u.id
                          ? 'bg-amber-400 border-black text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-black'
                          : 'bg-white border-black text-neutral-500 hover:bg-neutral-50 font-bold'
                      }`}
                    >
                      <div>
                        <span className="font-black block text-[11px] uppercase">{u.name}</span>
                        <span className="text-[9px] text-neutral-600 font-mono block">{u.email}</span>
                      </div>
                      <span className="text-[8px] px-1.5 py-0.5 rounded-none font-mono uppercase tracking-wider font-black border-2 border-black bg-white text-black">
                        {u.role}
                      </span>
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handleOAuthSignIn(selectedUserId)}
                  disabled={isLoggingIn}
                  className="w-full py-2.5 bg-white hover:bg-gray-100 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition flex items-center justify-center gap-2 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                >
                  {isLoggingIn ? (
                    <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <>
                      <svg className="w-3.5 h-3.5 mr-1" viewBox="0 0 24 24">
                        <path fill="#EA4335" d="M12 5.04c1.66 0 3.2.57 4.38 1.69l3.27-3.27C17.68 1.54 14.98 1 12 1 7.35 1 3.37 3.65 1.39 7.5l3.85 2.99C6.22 7.02 8.89 5.04 12 5.04z" />
                        <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.46c-.29 1.48-1.14 2.73-2.4 3.58l3.73 2.89c2.18-2.01 3.7-4.97 3.7-8.62z" />
                        <path fill="#FBBC05" d="M5.24 14.9C4.99 14.15 4.85 13.35 4.85 12s.14-2.15.39-2.9L1.39 6.11C.5 7.89 0 9.89 0 12s.5 4.11 1.39 5.89l3.85-2.99z" />
                        <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.91l-3.73-2.89c-1.03.69-2.35 1.1-4.23 1.1-3.11 0-5.78-1.98-6.76-4.96L1.39 16.33C3.37 20.35 7.35 23 12 23z" />
                      </svg>
                      Sign In with Google
                    </>
                  )}
                </button>
              </div>

              {/* Separator */}
              <div className="flex items-center justify-between text-[9px] text-neutral-400 uppercase font-black tracking-wider">
                <span className="h-[2px] bg-black flex-1"></span>
                <span className="px-2">or corporate email</span>
                <span className="h-[2px] bg-black flex-1"></span>
              </div>

              {/* Corporate email login */}
              <form onSubmit={handleCustomEmailSignIn} className="space-y-4">
                <div>
                  <label className="text-[9px] font-black text-black uppercase tracking-wider block mb-1">
                    Corporate Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-4 h-4 text-black stroke-[2.5]" />
                    <input
                      type="email"
                      placeholder="name@nexmotion.co.za"
                      value={customEmail}
                      onChange={e => setCustomEmail(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black placeholder-neutral-500 focus:outline-none focus:bg-amber-50/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[9px] font-black text-black uppercase tracking-wider block mb-1">
                    Security PIN (Required for @nexmotion.co.za)
                  </label>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-3 w-4 h-4 text-black stroke-[2.5]" />
                    <input
                      type="password"
                      placeholder="Enter security PIN"
                      value={customPin}
                      onChange={e => setCustomPin(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black placeholder-neutral-500 focus:outline-none focus:bg-amber-50/10"
                    />
                  </div>
                  <span className="text-[8px] font-bold text-neutral-500 mt-1 block uppercase leading-relaxed">
                    NexMotion employees must enter their 7-digit corporate system PIN to gain secure workspace access.
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isLoggingIn || !customEmail}
                  className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition flex items-center justify-center gap-2 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] disabled:opacity-55"
                >
                  Verify Email & Login
                </button>
              </form>

            </div>
          ) : (
            
            /* Account Creation form */
            <form onSubmit={handleSignupSubmit} className="space-y-4 text-black">
              
              <div>
                <label className="text-[9px] font-black text-black uppercase tracking-wider block mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Calvin Costa"
                  value={signupName}
                  onChange={e => setSignupName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black placeholder-neutral-500 focus:outline-none focus:bg-amber-50/10"
                  required
                />
              </div>

              <div>
                <label className="text-[9px] font-black text-black uppercase tracking-wider block mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. name@domain.com"
                  value={signupEmail}
                  onChange={e => setSignupEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black placeholder-neutral-500 focus:outline-none focus:bg-amber-50/10"
                  required
                />
              </div>

              <div>
                <label className="text-[9px] font-black text-black uppercase tracking-wider block mb-1">
                  Organization Role Profile
                </label>
                <select
                  value={signupRole}
                  onChange={e => setSignupRole(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-black uppercase text-black focus:outline-none"
                >
                  <option value="ceo">CEO (Full permissions, Document vault author, team invites)</option>
                  <option value="pm">Project Manager (Checklists, bid preparations, status shifts)</option>
                  <option value="viewer">Viewer (Read-only pipeline, specific tender tasks)</option>
                </select>
                <span className="text-[8px] font-bold text-neutral-500 mt-1.5 block uppercase leading-relaxed">
                  Roles dictate platform permissions in compliance with the South African POPIA regulations.
                </span>
              </div>

              <button
                type="submit"
                disabled={isLoggingIn || !signupName || !signupEmail}
                className="w-full mt-2 py-3 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition flex items-center justify-center gap-2 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] disabled:opacity-55"
              >
                {isLoggingIn ? (
                  <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
                    <span>Create Account & Join</span>
                  </>
                )}
              </button>

            </form>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 w-full py-6 text-center text-[10px] font-bold text-neutral-500 uppercase tracking-wider">
        NexMotion TMS v2.0 • Secured under South African POPIA Regulations • Private Enterprise Asset
      </footer>
    </div>
  );
};
