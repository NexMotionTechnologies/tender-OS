import React from 'react';
import { ArrowRight, ShieldCheck, Zap, AlertTriangle, Database, Search, FileText, BarChart3, Clock, CheckCircle } from 'lucide-react';

interface LandingPageProps {
  onStartLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStartLogin }) => {
  return (
    <div className="min-h-screen bg-white text-black flex flex-col font-sans">
      {/* Header/Nav */}
      <header className="border-b-[3px] border-black bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-none bg-amber-400 border-2 border-black flex items-center justify-center font-black text-black text-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              N
            </div>
            <span className="font-black tracking-tighter text-xl text-black uppercase">
              NexMotion <span className="text-amber-500 font-mono text-xs font-black">TMS</span>
            </span>
          </div>
          <nav className="flex items-center space-x-6">
            <a href="#how-it-works" className="text-xs font-black uppercase tracking-wider text-black hover:underline transition">How it works</a>
            <a href="#features" className="text-xs font-black uppercase tracking-wider text-black hover:underline transition">Features</a>
            <button
              onClick={onStartLogin}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 border-2 border-black text-black text-xs font-black uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
            >
              Sign In
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-24 md:py-32 bg-white text-black border-b-[3px] border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-none bg-amber-100 text-black border-2 border-black mb-6 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-[10px] font-black uppercase">
            <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
            <span className="tracking-wider">Sourcing Compliance Redefined</span>
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-black max-w-4xl mx-auto leading-tight uppercase">
            Never miss a government <br />
            <span className="bg-amber-400 border-2 border-black px-4 py-1.5 inline-block text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mt-2">
              tender deadline again
            </span>
          </h1>
          <p className="mt-8 text-sm sm:text-base text-neutral-700 max-w-2xl mx-auto leading-relaxed font-bold uppercase">
            Eliminate the strain of fragmented, manual bid-tracking across Limpopo, Free State, and Gauteng. 
            Automate discovery, analyze compliance with Gemini AI, and submit winning bids.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-6">
            <button
              onClick={onStartLogin}
              className="w-full sm:w-auto px-8 py-4 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black text-xs font-black uppercase tracking-wider rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center gap-2 transition active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
            >
              Sign In / Request Access <ArrowRight className="w-5 h-5 stroke-[2.5]" />
            </button>
            <a
              href="#how-it-works"
              className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-gray-100 text-black border-2 border-black text-xs font-black uppercase tracking-wider rounded-none flex items-center justify-center transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
            >
              See how it works
            </a>
          </div>
        </div>

        {/* Backdrop Glow removed to preserve clean high contrast flat design */}
      </section>

      {/* Problem/Solution Strip */}
      <section className="py-16 border-b-[3px] border-black bg-gray-50 text-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col sm:flex-row gap-4 bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className="p-3 bg-red-100 text-red-600 border-2 border-black rounded-none h-fit w-fit shrink-0">
                <AlertTriangle className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-black">Manual Chaos</span>
                <h3 className="text-xs font-black text-black mt-1 uppercase">5 Hours of Manual Searching</h3>
                <p className="text-xs text-neutral-600 mt-1 font-semibold leading-normal">Sifting through dozens of provincial bulletins daily with high human error rates.</p>
                <div className="mt-3 text-[10px] font-black text-black bg-amber-100 border border-black px-2 py-1 rounded-none w-fit uppercase tracking-tight flex items-center gap-1">
                  NexMotion Way: Ingest & Scrape in 30 Secs <Zap className="w-3.5 h-3.5 fill-current" />
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className="p-3 bg-red-100 text-red-600 border-2 border-black rounded-none h-fit w-fit shrink-0">
                <Clock className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-black">Lost Opportunities</span>
                <h3 className="text-xs font-black text-black mt-1 uppercase">Missed Deadlines</h3>
                <p className="text-xs text-neutral-600 mt-1 font-semibold leading-normal">Finding a tender 2 days before close, making proper compliance compilation impossible.</p>
                <div className="mt-3 text-[10px] font-black text-black bg-amber-100 border border-black px-2 py-1 rounded-none w-fit uppercase tracking-tight flex items-center gap-1">
                  NexMotion Way: Automated 7/3/1-day email alerts <CheckCircle className="w-3.5 h-3.5 fill-current" />
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className="p-3 bg-red-100 text-red-600 border-2 border-black rounded-none h-fit w-fit shrink-0">
                <FileText className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-black">Document Burden</span>
                <h3 className="text-xs font-black text-black mt-1 uppercase">Repetitive Document Search</h3>
                <p className="text-xs text-neutral-600 mt-1 font-semibold leading-normal">Hunting down SARS certificates, B-BBEE letters, and insurance deeds for every new bid.</p>
                <div className="mt-3 text-[10px] font-black text-black bg-amber-100 border border-black px-2 py-1 rounded-none w-fit uppercase tracking-tight flex items-center gap-1">
                  NexMotion Way: One-click Document Vault attach <Database className="w-3.5 h-3.5 fill-current" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 bg-white text-black border-b-[3px] border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-black text-black tracking-tight sm:text-4xl uppercase">The Automated Sourcing Flow</h2>
            <p className="mt-4 text-xs font-bold text-neutral-600 uppercase">
              NexMotion TMS manages the full bid lifecycle, turning hours of administrative struggle into a single, cohesive workflow.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-none bg-white border-[3px] border-black text-black flex items-center justify-center font-black text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-6">
                1
              </div>
              <h3 className="text-xs font-black text-black uppercase">Discover</h3>
              <p className="text-xs text-neutral-600 mt-2 max-w-xs font-semibold leading-relaxed">
                Daily automated scrapers extract new ICT tenders from E-Tenders, provincial portals, and municipalities.
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-none bg-white border-[3px] border-black text-black flex items-center justify-center font-black text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-6">
                2
              </div>
              <h3 className="text-xs font-black text-black uppercase">Analyze</h3>
              <p className="text-xs text-neutral-600 mt-2 max-w-xs font-semibold leading-relaxed">
                Gemini AI processes raw tender spec documents, evaluating fit scores and compliance requirement lists instantly.
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-none bg-white border-[3px] border-black text-black flex items-center justify-center font-black text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-6">
                3
              </div>
              <h3 className="text-xs font-black text-black uppercase">Track</h3>
              <p className="text-xs text-neutral-600 mt-2 max-w-xs font-semibold leading-relaxed">
                Drag-and-drop Kanban pipeline gives real-time visibility to CEO, PMs, and Viewers.
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-none bg-white border-[3px] border-black text-black flex items-center justify-center font-black text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-6">
                4
              </div>
              <h3 className="text-xs font-black text-black uppercase">Submit</h3>
              <p className="text-xs text-neutral-600 mt-2 max-w-xs font-semibold leading-relaxed">
                Leverage a reusable, encrypted Document Library to attach compliance credentials with one click.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Highlights */}
      <section id="features" className="py-24 bg-gray-50 text-black border-b-[3px] border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-3xl font-black text-black tracking-tight sm:text-4xl uppercase">Platform Features</h2>
            <p className="mt-4 text-xs font-bold text-neutral-600 uppercase">
              A comprehensive toolbelt tailored specifically for South African procurement requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <Search className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">Automated Tender Discovery</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Connects directly to E-Tenders, GIBB Portal, and municipalities across GP, FS, and LP to discover new RFPs.
              </p>
            </div>

            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <Zap className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">AI-Powered Fit Scoring</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Deep analysis engine maps incoming requirements against historical capability assets and rates opportunities automatically.
              </p>
            </div>

            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <BarChart3 className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">Kanban Pipeline</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Track status updates in real-time from Identified, Shortlisted, and Preparing, through to Submitted, Won, or Lost.
              </p>
            </div>

            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <Clock className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">Deadline Alerts</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Receive proactive email and dashboard warnings at 7-day, 3-day, and 1-day thresholds to protect active submissions.
              </p>
            </div>

            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <Database className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">Document Vault & Reuse</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Keep an up-to-date central storage for SARS tax pins, B-BBEE certificates, and insurance binders with active version control.
              </p>
            </div>

            <div className="bg-white p-8 rounded-none border-[3px] border-black hover:bg-neutral-50 transition shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <FileText className="w-8 h-8 text-black stroke-[2.5] mb-6" />
              <h3 className="text-xs font-black text-black uppercase">Analytics & Reporting</h3>
              <p className="text-xs text-neutral-600 mt-3 leading-relaxed font-semibold">
                Evaluate win rates, submission ratios, forecast values, and performance breakdowns by category and municipality.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Compliance Strip */}
      <section className="bg-white py-16 border-b-[3px] border-black text-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-3 text-black bg-white px-4 py-2 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-xs font-black uppercase">
            <ShieldCheck className="w-5 h-5 text-emerald-600 stroke-[2.5]" />
            <span className="font-bold">Fully POPIA Compliant & Encrypted</span>
          </div>
          <p className="text-xs text-neutral-600 max-w-xl mx-auto font-semibold uppercase mt-4">
            NexMotion Technologies enforces role-based access control (RBAC), multi-layer document scanning, and standard temporal data retention policies.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t-2 border-black py-12 text-black text-xs mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6 font-bold uppercase">
          <div className="flex items-center space-x-2">
            <span className="text-black font-black">NexMotion Technologies (Pty) Ltd</span>
          </div>
          <div className="text-neutral-600">
            Contact: support@nexmotion.co.za | Johannesburg, South Africa
          </div>
          <div>
            <button onClick={onStartLogin} className="text-black hover:underline transition underline font-black">
              Staff Portal Access
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
