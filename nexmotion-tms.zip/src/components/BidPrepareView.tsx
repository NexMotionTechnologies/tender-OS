import React, { useState } from 'react';
import { useApiStore } from '../store';
import { ArrowLeft, CheckSquare, Square, ClipboardList, Database, Sparkles, Calendar, User, Upload, ArrowRight, DollarSign, PartyPopper } from 'lucide-react';

interface BidPrepareViewProps {
  tenderId: string;
  onBack: () => void;
  onNavigateToDocs: () => void;
}

export const BidPrepareView: React.FC<BidPrepareViewProps> = ({ tenderId, onBack, onNavigateToDocs }) => {
  const { tenders, documents, allUsers, updateChecklistItem, attachDocToChecklist, submitBid, activeUser } = useApiStore();
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [itemAssignee, setItemAssignee] = useState('');
  const [itemDueDate, setItemDueDate] = useState('');
  
  // Submit modal states
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [bidValue, setBidValue] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const tender = tenders.find(t => t.id === tenderId);

  if (!tender) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-400 font-semibold">Tender not found.</p>
        <button onClick={onBack} className="mt-4 text-amber-500 hover:underline">Go Back</button>
      </div>
    );
  }

  const checklist = tender.checklist || [];
  
  // Calculate completion percentage
  const totalItems = checklist.length;
  const completedItems = checklist.filter(item => item.completed).length;
  const completionPercentage = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
  const isFullyCompliant = completionPercentage === 100;

  const handleToggleCheck = async (index: number, currentVal: boolean) => {
    if (activeUser?.role === 'viewer') return;
    await updateChecklistItem(tender.id, index, !currentVal);
  };

  const handleSaveItemDetails = async (index: number) => {
    if (activeUser?.role === 'viewer') return;
    await updateChecklistItem(
      tender.id,
      index,
      undefined, // don't toggle completed
      itemAssignee || undefined,
      itemDueDate || undefined
    );
    setEditingItemIndex(null);
  };

  const handleAttachDocument = async (index: number, docId: string) => {
    if (activeUser?.role === 'viewer') return;
    try {
      await attachDocToChecklist(tender.id, index, docId);
    } catch (err) {
      console.error(err);
      alert('Failed to attach compliance document.');
    }
  };

  const handleSubmitFinalBid = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bidValue) return;

    setIsSubmitting(true);
    try {
      await submitBid(tender.id, Number(bidValue));
      setShowSubmitModal(false);
      onBack(); // Go back to details
    } catch (err) {
      console.error(err);
      alert('Submission failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      
      {/* Back Header */}
      <div className="shrink-0 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b-4 border-black">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-black text-black uppercase tracking-wider border-2 border-black bg-white hover:bg-gray-100 px-3 py-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
        >
          <ArrowLeft className="w-4 h-4 stroke-[2.5]" /> Back to Tender Details
        </button>

        {tender.status !== 'submitted' && (
          <button
            onClick={() => setShowSubmitModal(true)}
            disabled={!isFullyCompliant && tender.status !== 'ready'}
            className={`px-5 py-2.5 rounded-none text-xs font-black uppercase tracking-wider border-2 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1.5 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
              isFullyCompliant
                ? 'bg-emerald-400 hover:bg-emerald-300 text-black'
                : 'bg-gray-100 text-neutral-400 cursor-not-allowed opacity-50'
            }`}
          >
            <PartyPopper className="w-4 h-4 stroke-[2.5]" /> Submit Tender Bid Proposal
          </button>
        )}
      </div>

      {/* Main Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Compliance Checklist */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Progress Banner */}
          <div className="bg-white border-[3px] border-black rounded-none p-6 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-neutral-500 uppercase tracking-wider block">PROPOSAL ASSEMBLY PROGRESS</span>
                <h2 className="text-xl font-black text-black uppercase mt-1">Bid Compliance Checklist</h2>
              </div>
              <span className={`text-3xl font-black font-mono ${isFullyCompliant ? 'text-emerald-500' : 'text-amber-500'}`}>
                {completionPercentage}%
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-white border-2 border-black h-4 rounded-none overflow-hidden">
              <div
                className={`h-full border-r border-black transition-all duration-500 ${isFullyCompliant ? 'bg-emerald-400' : 'bg-amber-400'}`}
                style={{ width: `${completionPercentage}%` }}
              ></div>
            </div>

            <p className="text-xs text-neutral-700 leading-relaxed font-semibold">
              {isFullyCompliant
                ? '✓ All mandatory requirements and SBD compliance forms are compiled and attached. Proposal is ready for final corporate sign-off.'
                : `Attached ${completedItems} of ${totalItems} requested documents. Pick pre-approved documents from NexMotion's central vault below.`}
            </p>
          </div>

          {/* Checklist Items list */}
          <div className="bg-white border-[3px] border-black rounded-none p-5 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="space-y-3.5">
              {checklist.map((item, index) => {
                const isEditing = editingItemIndex === index;
                const assignedMember = allUsers.find(u => u.id === item.assignedTo);

                // Look up matching reusable documents in the library to offer "Attach"
                const matchingDocs = documents.filter(d => d.category.toLowerCase().includes(item.documentCategory.toLowerCase()));

                return (
                  <div
                    key={index}
                    className={`p-4 rounded-none border-2 border-black transition ${
                      item.completed
                        ? 'bg-emerald-50/30'
                        : 'bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3.5 justify-between">
                      <div className="flex items-start gap-3">
                        {/* Checkbox trigger (restricted for Viewers) */}
                        <button
                          onClick={() => handleToggleCheck(index, item.completed)}
                          disabled={activeUser?.role === 'viewer'}
                          className={`mt-0.5 shrink-0 ${activeUser?.role === 'viewer' ? 'cursor-not-allowed opacity-60' : 'text-black hover:scale-105'}`}
                        >
                          {item.completed ? (
                            <CheckSquare className="w-5 h-5 text-emerald-500 stroke-[2.5]" />
                          ) : (
                            <Square className="w-5 h-5 text-neutral-400 stroke-[2.5]" />
                          )}
                        </button>
                        
                        <div>
                          <span className="text-[10px] uppercase font-black tracking-wider text-neutral-500 font-mono">
                            TYPE: {item.documentCategory.replace(/([A-Z])/g, ' $1').toUpperCase()}
                          </span>
                          <h4 className={`text-xs font-black uppercase leading-snug mt-0.5 ${item.completed ? 'text-neutral-400 line-through' : 'text-black'}`}>
                            {item.title}
                          </h4>
                          
                          {/* Assignment & Due metadata */}
                          <div className="flex items-center space-x-4 mt-2.5 text-[10px] text-neutral-600 font-bold uppercase">
                            <span className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-black stroke-[2.5]" />
                              ASSIGNEE: <strong className="text-black">{assignedMember ? assignedMember.name.toUpperCase() : 'UNASSIGNED'}</strong>
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-black stroke-[2.5]" />
                              DUE: <strong className="text-black">{item.dueDate ? new Date(item.dueDate).toLocaleDateString('en-ZA') : 'TBD'}</strong>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Edit Details Button */}
                      {activeUser?.role !== 'viewer' && (
                        <button
                          onClick={() => {
                            if (isEditing) {
                              setEditingItemIndex(null);
                            } else {
                              setEditingItemIndex(index);
                              setItemAssignee(item.assignedTo || '');
                              setItemDueDate(item.dueDate || '');
                            }
                          }}
                          className="text-[10px] font-black uppercase text-black hover:underline transition"
                        >
                          {isEditing ? 'Cancel' : 'Edit Task'}
                        </button>
                      )}
                    </div>

                    {/* Inline detail editor */}
                    {isEditing && (
                      <div className="mt-4 pt-3.5 border-t-2 border-black grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                        <div className="space-y-1">
                          <span className="text-[9px] font-black text-black uppercase tracking-wider block">Assign Task</span>
                          <select
                            value={itemAssignee}
                            onChange={e => setItemAssignee(e.target.value)}
                            className="w-full p-2 bg-white border-2 border-black rounded-none text-[11px] font-bold text-black focus:outline-none"
                          >
                            <option value="">Unassigned</option>
                            {allUsers.map(u => (
                              <option key={u.id} value={u.id}>{u.name}</option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[9px] font-black text-black uppercase tracking-wider block">Due Date</span>
                          <input
                            type="date"
                            value={itemDueDate}
                            onChange={e => setItemDueDate(e.target.value)}
                            className="w-full p-2 bg-white border-2 border-black rounded-none text-[11px] font-bold text-black focus:outline-none"
                          />
                        </div>

                        <button
                          onClick={() => handleSaveItemDetails(index)}
                          className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-[11px] rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                        >
                          Save Task Details
                        </button>
                      </div>
                    )}

                    {/* Document library attach list */}
                    {!item.completed && !isEditing && activeUser?.role !== 'viewer' && (
                      <div className="mt-3.5 pt-3.5 border-t-2 border-black">
                        <span className="text-[9px] font-black text-neutral-500 uppercase block tracking-wider mb-2">
                          Matching Central Vault Assets
                        </span>
                        {matchingDocs.length > 0 ? (
                          <div className="space-y-2">
                            {matchingDocs.map(doc => {
                              const isExpiring = doc.status === 'expiringSoon';
                              return (
                                <div
                                  key={doc.id}
                                  className="p-2.5 bg-gray-50 border-2 border-black rounded-none flex items-center justify-between text-[11px]"
                                >
                                  <div>
                                    <span className="font-black text-black uppercase truncate block max-w-xs">{doc.fileName}</span>
                                    {isExpiring && (
                                      <span className="text-[9px] text-red-600 font-bold uppercase block mt-0.5">
                                        ⚠ Warning: Expiring soon ({doc.expiryDate})
                                      </span>
                                    )}
                                  </div>
                                  <button
                                    onClick={() => handleAttachDocument(index, doc.id)}
                                    className="px-2.5 py-1.5 border-2 border-black bg-white hover:bg-amber-400 text-black text-[10px] font-black uppercase tracking-wider rounded-none flex items-center gap-1 transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                                  >
                                    <Database className="w-3 h-3 stroke-[2.5]" /> Attach & Auto-complete
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="text-[10px] text-neutral-600 font-bold flex items-center justify-between bg-neutral-150 border-2 border-dashed border-black p-2.5 rounded-none">
                            <span>No pre-approved {item.documentCategory} in library.</span>
                            <button
                              onClick={onNavigateToDocs}
                              className="text-black font-black uppercase underline hover:no-underline"
                            >
                              Go Upload New Asset +
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Shows attached document detail if complete */}
                    {item.completed && item.attachedDocumentId && (
                      <div className="mt-2.5 flex items-center gap-1.5 text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-500 px-2.5 py-1.5 rounded-none font-bold uppercase">
                        <Database className="w-3.5 h-3.5 shrink-0 stroke-[2.5]" />
                        <span>Compliance document attached successfully from vault.</span>
                      </div>
                    )}

                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right 1 Column: Compliance Guidelines */}
        <div className="space-y-6">
          <div className="bg-white border-[3px] border-black rounded-none p-5 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
            <h3 className="text-xs font-black text-black uppercase tracking-wider pb-2 border-b-2 border-black">
              South African Sourcing Guidelines
            </h3>
            
            <div className="space-y-3.5 text-xs text-neutral-800 leading-relaxed font-medium">
              <p>
                To avoid immediate administrative disqualification at tender opening, verify that:
              </p>
              
              <ul className="space-y-3">
                <li className="flex gap-2.5">
                  <span className="text-black font-black shrink-0">•</span>
                  <span><strong>SARS Tax Pin</strong> is active with a verified compliant status.</span>
                </li>
                <li className="flex gap-2.5">
                  <span className="text-black font-black shrink-0">•</span>
                  <span><strong>B-BBEE Affidavit</strong> or Certificate is sworn by a Commissioner of Oaths and hasn't expired.</span>
                </li>
                <li className="flex gap-2.5">
                  <span className="text-black font-black shrink-0">•</span>
                  <span><strong>COIDA Letter of Good Standing</strong> is issued by the Compensation Commissioner.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>

      {/* Submit Bid Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-md bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 text-black">
            
            <div className="pb-3 border-b-2 border-black flex items-center justify-between">
              <h3 className="font-black text-lg text-black uppercase tracking-tight flex items-center gap-2">
                <PartyPopper className="w-5 h-5 text-black" /> Submit Bid Proposal
              </h3>
              <button onClick={() => setShowSubmitModal(false)} className="text-black hover:bg-gray-100 px-2 py-1 border-2 border-black text-xs font-black uppercase rounded-none">
                Cancel
              </button>
            </div>

            <form onSubmit={handleSubmitFinalBid} className="space-y-5 mt-4">
              <p className="text-xs text-neutral-700 leading-normal font-semibold">
                All checklist criteria are met! Enter the final commercial proposal value to record submission and update the pipeline.
              </p>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Final Bid Value (ZAR)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-black font-mono font-black text-sm">R</span>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 3500000"
                    value={bidValue}
                    onChange={e => setBidValue(e.target.value)}
                    className="w-full pl-8 pr-4 py-2.5 bg-white border-2 border-black rounded-none text-sm text-black placeholder-neutral-500 font-bold focus:outline-none focus:bg-amber-50/20 transition"
                  />
                </div>
                <span className="text-[10px] text-neutral-500 font-bold mt-1 block uppercase font-mono">
                  Tender estimated max: R{(tender.budget.max).toLocaleString('en-ZA')}
                </span>
              </div>

              <div className="pt-4 border-t-2 border-black flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="px-4 py-2 bg-white hover:bg-gray-100 text-xs font-black uppercase border-2 border-black rounded-none transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-400 hover:bg-emerald-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1 transition disabled:opacity-60 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  {isSubmitting ? 'SUBMITTING...' : 'Mark Submitted & Lock Bid'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
