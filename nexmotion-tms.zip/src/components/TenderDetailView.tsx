import React, { useState } from 'react';
import { useApiStore } from '../store';
import { Sparkles, Calendar, DollarSign, MapPin, ExternalLink, ArrowLeft, Send, CheckCircle2, User, UserPlus, FileWarning, HelpCircle } from 'lucide-react';

interface TenderDetailViewProps {
  tenderId: string;
  onBack: () => void;
  onNavigateToPrepare: (id: string) => void;
}

export const TenderDetailView: React.FC<TenderDetailViewProps> = ({ tenderId, onBack, onNavigateToPrepare }) => {
  const { tenders, allUsers, updateTenderStatus, addComment, assignTender, activeUser } = useApiStore();
  const [commentText, setCommentText] = useState('');
  const [showAssignDropdown, setShowAssignDropdown] = useState(false);

  const tender = tenders.find(t => t.id === tenderId);

  if (!tender) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-400 font-semibold">Tender not found.</p>
        <button onClick={onBack} className="mt-4 text-amber-500 hover:underline">Go Back</button>
      </div>
    );
  }

  // Calculate days left
  const dlDate = new Date(tender.deadline);
  const now = new Date('2026-07-06T03:45:58-07:00');
  const diffTime = dlDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const isUrgent = diffDays > 0 && diffDays <= 7;

  const handleStatusChange = async (nextStatus: string) => {
    if (activeUser?.role === 'viewer') return;
    await updateTenderStatus(tender.id, nextStatus);
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    await addComment(tender.id, commentText);
    setCommentText('');
  };

  const handleToggleAssignee = async (userId: string) => {
    if (activeUser?.role === 'viewer') return;
    let nextAssignments = [...tender.assignedTo];
    if (nextAssignments.includes(userId)) {
      nextAssignments = nextAssignments.filter(uid => uid !== userId);
    } else {
      nextAssignments.push(userId);
    }
    await assignTender(tender.id, nextAssignments);
  };

  const fitScore = tender.analysis.fitScore;

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      
      {/* Back Button & Page Nav */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shrink-0 pb-4 border-b-4 border-black">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-black text-black uppercase tracking-wider border-2 border-black bg-white hover:bg-gray-100 px-3 py-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
        >
          <ArrowLeft className="w-4 h-4 stroke-[2.5]" /> Back to Sourcing Queue
        </button>

        {/* Action Button Strip */}
        {activeUser?.role !== 'viewer' && (
          <div className="flex items-center gap-2">
            {tender.status === 'identified' && (
              <>
                <button
                  onClick={() => handleStatusChange('shortlisted')}
                  className="px-4 py-2 bg-black hover:bg-neutral-900 border-2 border-black text-white text-xs font-black uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] rounded-none transition"
                >
                  Shortlist Opportunity
                </button>
                <button
                  onClick={() => handleStatusChange('lost')} // mark skipped
                  className="px-4 py-2 bg-white hover:bg-gray-100 border-2 border-black text-black text-xs font-black uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] rounded-none transition"
                >
                  Skip
                </button>
              </>
            )}

            {tender.status === 'shortlisted' && (
              <>
                <button
                  onClick={() => handleStatusChange('preparing')}
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-black text-xs font-black uppercase tracking-wider border-2 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] rounded-none transition"
                >
                  Start Preparing Bid Proposal
                </button>
                <button
                  onClick={() => handleStatusChange('lost')}
                  className="px-4 py-2 bg-white hover:bg-gray-100 border-2 border-black text-black text-xs font-black uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] rounded-none transition"
                >
                  Archive/Skip
                </button>
              </>
            )}

            {tender.status === 'preparing' && (
              <button
                onClick={() => onNavigateToPrepare(tender.id)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black uppercase tracking-wider border-2 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] rounded-none flex items-center gap-1.5 transition"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0 stroke-[2.5]" /> Assemble Bid Compliance (Prepare Flow)
              </button>
            )}
            
            {tender.status === 'submitted' && (
              <div className="text-xs bg-emerald-400 text-black font-black border-2 border-black px-4 py-2 rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-mono uppercase">
                ✓ SUBMITTED: ZAR {tender.bid?.bidValue ? tender.bid.bidValue.toLocaleString('en-ZA') : 'TBD'}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Grid Detail Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Core Info and AI Report Card */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* 1. Header Metadata Box */}
          <div className="bg-white border-[3px] border-black rounded-none p-6 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black font-mono bg-amber-400 text-black border border-black px-2.5 py-0.5 rounded-none uppercase">
                {tender.source.toUpperCase()}
              </span>
              <span className="text-[10px] font-black font-mono bg-black text-white border border-black px-2.5 py-0.5 rounded-none uppercase">
                STATUS: {tender.status.toUpperCase()}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-black tracking-tight leading-snug uppercase">
              {tender.title}
            </h1>

            {/* Icon metrics row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t-2 border-black text-xs">
              <div className="flex items-center space-x-3 text-black">
                <MapPin className="w-5 h-5 text-black shrink-0 stroke-[2.5]" />
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase font-black tracking-wider block">Municipality / Region</span>
                  <span className="font-black text-black uppercase">{tender.municipality}, {tender.province}</span>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-black">
                <DollarSign className="w-5 h-5 text-black shrink-0 stroke-[2.5]" />
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase font-black tracking-wider block">Estimated Range (ZAR)</span>
                  <span className="font-black text-black">R{(tender.budget.min / 1000000).toFixed(1)}M - R{(tender.budget.max / 1000000).toFixed(1)}M</span>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-black">
                <Calendar className="w-5 h-5 text-black shrink-0 stroke-[2.5]" />
                <div>
                  <span className="text-[10px] text-neutral-500 uppercase font-black tracking-wider block">Closing Deadline</span>
                  <span className={`font-black ${isUrgent ? 'text-red-600 font-black' : ''}`}>
                    {new Date(tender.deadline).toLocaleDateString('en-ZA')} ({diffDays <= 0 ? 'CLOSED' : `${diffDays} DAYS LEFT`})
                  </span>
                </div>
              </div>
            </div>

            {tender.link && (
              <div className="pt-2">
                <a
                  href={tender.link}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-black uppercase text-black hover:underline transition"
                >
                  View Original Bulletin Specification <ExternalLink className="w-3.5 h-3.5 stroke-[2.5]" />
                </a>
              </div>
            )}
          </div>

          {/* 2. GEMINI AI Report Card / Analysis Panel */}
          <div className="bg-white border-[3px] border-black rounded-none p-6 space-y-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center justify-between pb-3 border-b-2 border-black">
              <h2 className="font-black text-sm text-black uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-black stroke-[2.5]" /> Gemini Sourcing AI Fit Score breakdown
              </h2>
              <span className={`text-xs font-black px-2.5 py-1 rounded-none border-2 border-black flex items-center gap-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
                fitScore >= 85 ? 'bg-emerald-400 text-black' :
                fitScore >= 70 ? 'bg-amber-400 text-black' :
                'bg-red-500 text-white'
              }`}>
                {tender.analysis.recommendation} Recommendation ({fitScore}% Match)
              </span>
            </div>

            {/* Score Breakdowns Meter */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-gray-50 p-4 border-2 border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <div>
                <span className="text-[10px] font-black text-slate-500 uppercase block tracking-wider">Technical Fit</span>
                <span className="text-xl font-black text-black block mt-1">{tender.analysis.scoreBreakdown.technical}%</span>
                <div className="w-full bg-white border border-black h-3.5 rounded-none mt-2 overflow-hidden">
                  <div className="bg-amber-400 h-full border-r border-black" style={{ width: `${tender.analysis.scoreBreakdown.technical}%` }}></div>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-black text-slate-500 uppercase block tracking-wider">Compliance Fit</span>
                <span className="text-xl font-black text-black block mt-1">{tender.analysis.scoreBreakdown.compliance}%</span>
                <div className="w-full bg-white border border-black h-3.5 rounded-none mt-2 overflow-hidden">
                  <div className="bg-amber-400 h-full border-r border-black" style={{ width: `${tender.analysis.scoreBreakdown.compliance}%` }}></div>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-black text-slate-500 uppercase block tracking-wider">Timeline Match</span>
                <span className="text-xl font-black text-black block mt-1">{tender.analysis.scoreBreakdown.timeline}%</span>
                <div className="w-full bg-white border border-black h-3.5 rounded-none mt-2 overflow-hidden">
                  <div className="bg-amber-400 h-full border-r border-black" style={{ width: `${tender.analysis.scoreBreakdown.timeline}%` }}></div>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-black text-slate-500 uppercase block tracking-wider">Budget Alignment</span>
                <span className="text-xl font-black text-black block mt-1">{tender.analysis.scoreBreakdown.budget}%</span>
                <div className="w-full bg-white border border-black h-3.5 rounded-none mt-2 overflow-hidden">
                  <div className="bg-amber-400 h-full border-r border-black" style={{ width: `${tender.analysis.scoreBreakdown.budget}%` }}></div>
                </div>
              </div>
            </div>

            {/* Capability Match explanation */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">AI Sourcing Summary</span>
              <p className="text-xs text-black leading-relaxed bg-neutral-50 p-4 border-2 border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-medium">
                {tender.analysis.capabilityMatch}
              </p>
            </div>

            {/* Requirements & Compliance Checklist Lists */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="space-y-3">
                <h3 className="text-xs font-black text-black uppercase tracking-wider pb-1.5 border-b-2 border-black">
                  Technical Requirements Identified
                </h3>
                <ul className="space-y-2">
                  {tender.analysis.requirements.map((req, i) => (
                    <li key={i} className="text-xs text-black flex items-start gap-2.5 font-semibold">
                      <span className="w-3.5 h-3.5 bg-black border border-black text-white flex items-center justify-center font-mono font-black text-[8px] mt-0.5 shrink-0 font-sans">✓</span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="text-xs font-black text-black uppercase tracking-wider pb-1.5 border-b-2 border-black">
                  Compliance Documents Demanded
                </h3>
                <ul className="space-y-2">
                  {tender.analysis.complianceNeeds.map((comp, i) => (
                    <li key={i} className="text-xs text-black flex items-start gap-2.5 font-semibold">
                      <span className="w-3.5 h-3.5 bg-blue-600 border border-black text-white flex items-center justify-center font-mono font-black text-[8px] mt-0.5 shrink-0 font-sans">!</span>
                      <span>{comp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Risks and Warning Panel */}
            <div className="p-4 bg-red-50 border-2 border-black rounded-none space-y-2.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              <h3 className="text-xs font-black text-red-600 uppercase tracking-wider flex items-center gap-1.5">
                <FileWarning className="w-4 h-4 shrink-0" /> Detected Bid Submission Risks
              </h3>
              <ul className="space-y-1.5">
                {tender.analysis.risks.map((risk, i) => (
                  <li key={i} className="text-xs text-black font-bold flex items-start gap-2">
                    <span className="text-red-600 select-none font-black">•</span>
                    <span>{risk}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

        </div>

        {/* Right 1 Column: Assignees, Comments & Thread */}
        <div className="space-y-6">
          
          {/* 1. Team Assignments */}
          <div className="bg-white border-[3px] border-black rounded-none p-5 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
            <div className="flex items-center justify-between pb-2 border-b-2 border-black">
              <h3 className="text-xs font-black text-black uppercase tracking-wider flex items-center gap-2">
                <User className="w-4 h-4 text-black" /> Assigned Personnel
              </h3>
              {activeUser?.role !== 'viewer' && (
                <button
                  onClick={() => setShowAssignDropdown(!showAssignDropdown)}
                  className="p-1 border-2 border-black bg-white hover:bg-gray-100 transition rounded-none shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                  title="Assign Team"
                >
                  <UserPlus className="w-4 h-4 text-black stroke-[2.5]" />
                </button>
              )}
            </div>

            {/* Assignment Dropdown Selector */}
            {showAssignDropdown && (
              <div className="bg-white p-2.5 border-2 border-black rounded-none space-y-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-black">
                <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Assign Teammate:</span>
                {allUsers.map(u => {
                  const isAssigned = tender.assignedTo.includes(u.id);
                  return (
                    <button
                      key={u.id}
                      onClick={() => handleToggleAssignee(u.id)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-none text-xs flex items-center justify-between transition border ${
                        isAssigned ? 'bg-black text-white border-black font-black' : 'text-black hover:bg-gray-100 border-transparent'
                      }`}
                    >
                      <span>{u.name} ({u.role.toUpperCase()})</span>
                      {isAssigned && <span className="font-bold text-[10px] uppercase">✓</span>}
                    </button>
                  );
                })}
              </div>
            )}

            {/* List current assigned members */}
            <div className="space-y-2">
              {tender.assignedTo.length > 0 ? (
                tender.assignedTo.map(uid => {
                  const member = allUsers.find(u => u.id === uid);
                  if (!member) return null;
                  return (
                    <div key={uid} className="flex items-center justify-between p-2.5 bg-white border-2 border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-black">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-6 h-6 rounded-none bg-black border border-black text-[10px] text-white flex items-center justify-center font-black animate-none">
                          {member.name.charAt(0)}
                        </div>
                        <span className="text-xs text-black font-black uppercase">{member.name}</span>
                      </div>
                      <span className="text-[9px] font-mono font-black text-neutral-500 uppercase">{member.role}</span>
                    </div>
                  );
                })
              ) : (
                <p className="text-xs text-neutral-500 text-center py-2 italic font-mono uppercase">Unassigned. Click plus icon to assign teammates.</p>
              )}
            </div>
          </div>

          {/* 2. Audit Trail / Discussion Thread */}
          <div className="bg-white border-[3px] border-black rounded-none p-5 flex flex-col h-[380px] min-h-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
            <h3 className="text-xs font-black text-black uppercase tracking-wider pb-2.5 border-b-2 border-black shrink-0">
              Audit Logs & Discussion
            </h3>

            {/* Chat Body */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1 min-h-0">
              {tender.comments.length > 0 ? (
                tender.comments.map(comment => (
                  <div key={comment.id} className="space-y-1 bg-gray-50 p-3 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-black">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="font-black text-black uppercase">{comment.userName}</span>
                      <span className="text-[9px] text-neutral-500 font-mono font-bold">
                        {new Date(comment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-700 font-medium leading-normal">{comment.text}</p>
                  </div>
                ))
              ) : (
                <div className="h-full flex items-center justify-center text-neutral-500 text-xs italic text-center px-4 font-mono uppercase">
                  No discussion. Record meeting actions or compliance clarifications here.
                </div>
              )}
            </div>

            {/* Chat Footer Input */}
            <form onSubmit={handlePostComment} className="pt-3 border-t-2 border-black shrink-0">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Ask team or record audit log..."
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black placeholder-neutral-500 font-bold focus:outline-none focus:bg-amber-50/20 transition"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-2 p-1.5 text-black hover:bg-gray-100 border-2 border-transparent hover:border-black rounded-none transition"
                >
                  <Send className="w-4 h-4 stroke-[2.5]" />
                </button>
              </div>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
};
