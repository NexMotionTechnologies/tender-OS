import React from 'react';
import { ShieldCheck, ArrowRight, Zap, Database, UserPlus, LogIn, ClipboardList, TrendingUp } from 'lucide-react';

interface IntroPageProps {
  onStartSignup: () => void;
  onStartLogin: () => void;
}

export const IntroPage: React.FC<IntroPageProps> = ({ onStartSignup, onStartLogin }) => {
  return (
    <div className="min-h-screen bg-neutral-100 text-black flex flex-col justify-between font-sans">
      
      {/* Header */}
      <header className="border-b-[3px] border-black bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-none bg-amber-400 border-2 border-black flex items-center justify-center font-black text-black text-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              N
            </div>
            <span className="font-black tracking-tighter text-xl text-black uppercase">
              NexMotion <span className="text-amber-500 font-mono text-xs font-black">TMS</span>
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={onStartLogin}
              className="px-4 py-2 bg-white hover:bg-neutral-50 border-2 border-black text-black text-xs font-black uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
            >
              Log In
            </button>
            <button
              onClick={onStartSignup}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 border-2 border-black text-black text-xs font-black uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
            >
              Sign Up
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl mx-auto px-6 py-12 flex flex-col justify-center items-center">
        
        {/* Sourcing State Notice (Aesthetic Banner) */}
        <div className="inline-flex items-center space-x-2.5 px-4 py-2 rounded-none bg-amber-100 text-black border-2 border-black mb-8 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-xs font-black uppercase tracking-wide">
          <ShieldCheck className="w-5 h-5 text-amber-500 stroke-[2.5]" />
          <span>Status: Clean Slate / System Ready</span>
        </div>

        {/* Hero Typography */}
        <div className="text-center max-w-3xl mb-12">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-black uppercase leading-none">
            Your Sourcing <br />
            <span className="bg-amber-400 border-2 border-black px-4 py-1 inline-block text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mt-3">
              Workspace Begins At Zero
            </span>
          </h1>
          <p className="mt-8 text-sm sm:text-base text-neutral-800 font-bold uppercase leading-relaxed">
            Welcome to NexMotion Tender Management System. No bids have been compiled, no documents have been uploaded, and no active tasks exist. The platform is ready for anyone to access, configure, and operate from scratch.
          </p>
        </div>

        {/* Dynamic Bento Cards Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl mb-12">
          
          {/* Pathway A: Create Account */}
          <div className="bg-white border-[3px] border-black p-8 rounded-none shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between hover:translate-x-[-1px] hover:translate-y-[-1px] hover:shadow-[7px_7px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div>
              <div className="w-12 h-12 bg-amber-100 border-2 border-black flex items-center justify-center text-black mb-6">
                <UserPlus className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-black uppercase text-black mb-2 tracking-tight">Create an Account</h3>
              <p className="text-xs text-neutral-600 font-semibold leading-relaxed mb-6">
                Register as a new CEO, Project Manager, or Viewer. Establish your user profile and claim your own isolated bidding dashboard.
              </p>
            </div>
            <button
              onClick={onStartSignup}
              className="w-full py-3.5 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition flex items-center justify-center gap-2 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
            >
              Get Started (Sign Up) <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

          {/* Pathway B: Sign In */}
          <div className="bg-white border-[3px] border-black p-8 rounded-none shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between hover:translate-x-[-1px] hover:translate-y-[-1px] hover:shadow-[7px_7px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div>
              <div className="w-12 h-12 bg-neutral-100 border-2 border-black flex items-center justify-center text-black mb-6">
                <LogIn className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-black uppercase text-black mb-2 tracking-tight">Sign In to Workspace</h3>
              <p className="text-xs text-neutral-600 font-semibold leading-relaxed mb-6">
                Already have an account? Or wish to switch between default team role profiles to test out the POPIA compliance and CEO permissions?
              </p>
            </div>
            <button
              onClick={onStartLogin}
              className="w-full py-3.5 bg-white hover:bg-neutral-50 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition flex items-center justify-center gap-2 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
            >
              Choose Profile (Sign In) <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

        </div>

        {/* Feature Overview Infographic */}
        <div className="bg-white border-[3px] border-black p-6 rounded-none w-full max-w-4xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div className="text-center mb-6">
            <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block font-mono">Platform Capabilities</span>
            <h4 className="text-sm font-black uppercase text-black mt-1">Four Steps to Launch Your First Sourcing Bid</h4>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-center font-bold">
            <div className="p-4 bg-gray-50 border border-black flex flex-col items-center">
              <Zap className="w-6 h-6 text-amber-500 mb-2 stroke-[2.5]" />
              <span className="text-[10px] uppercase text-black block">1. Scrape & Ingest</span>
              <p className="text-[9px] text-neutral-500 uppercase mt-1 leading-normal font-semibold">Pull RFPs in 30 seconds</p>
            </div>
            <div className="p-4 bg-gray-50 border border-black flex flex-col items-center">
              <ClipboardList className="w-6 h-6 text-amber-500 mb-2 stroke-[2.5]" />
              <span className="text-[10px] uppercase text-black block">2. Fit Analysis</span>
              <p className="text-[9px] text-neutral-500 uppercase mt-1 leading-normal font-semibold">Gemini AI checklist</p>
            </div>
            <div className="p-4 bg-gray-50 border border-black flex flex-col items-center">
              <Database className="w-6 h-6 text-amber-500 mb-2 stroke-[2.5]" />
              <span className="text-[10px] uppercase text-black block">3. Reusable Vault</span>
              <p className="text-[9px] text-neutral-500 uppercase mt-1 leading-normal font-semibold">SARS & B-BBEE letters</p>
            </div>
            <div className="p-4 bg-gray-50 border border-black flex flex-col items-center">
              <TrendingUp className="w-6 h-6 text-amber-500 mb-2 stroke-[2.5]" />
              <span className="text-[10px] uppercase text-black block">4. Win Bids</span>
              <p className="text-[9px] text-neutral-500 uppercase mt-1 leading-normal font-semibold">Track win rates securely</p>
            </div>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="bg-white border-t-2 border-black py-8 text-black text-[10px] font-black uppercase text-center tracking-widest">
        NexMotion Technologies (Pty) Ltd • Johannesburg, South Africa • POPIA Encrypted
      </footer>
    </div>
  );
};
