import React, { useState } from 'react';
import { useApiStore } from '../store';
import { Bell, User, ChevronDown, Check, ShieldAlert, Sparkles, RefreshCw } from 'lucide-react';

interface HeaderProps {
  onNavigate: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const { activeUser, allUsers, switchUser, emailAlerts, tenders, documents } = useApiStore();
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  if (!activeUser) return null;

  // Compute live system alerts for the notification center!
  // This satisfies the "deadline/expiry alerts" requirement dynamically.
  const systemAlerts: { id: string; title: string; message: string; type: 'warning' | 'info' | 'critical'; date: string }[] = [];

  // Add document alerts
  documents.forEach(d => {
    if (d.status === 'expiringSoon') {
      systemAlerts.push({
        id: 'doc_' + d.id,
        title: 'Document Expiring Soon',
        message: `${d.fileName} expires on ${d.issueDate ? d.expiryDate : 'soon'}. Please update this vault asset.`,
        type: 'warning',
        date: d.uploadedAt
      });
    }
  });

  // Add close tender deadlines
  tenders.forEach(t => {
    if (t.status === 'identified' || t.status === 'shortlisted' || t.status === 'preparing') {
      const deadlineDate = new Date(t.deadline);
      const now = new Date('2026-07-06T03:45:58-07:00'); // current simulated time
      const diffDays = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays > 0 && diffDays <= 7) {
        systemAlerts.push({
          id: 'tender_' + t.id,
          title: 'Upcoming Tender Deadline',
          message: `"${t.title}" closes in ${diffDays} day(s) (${diffDays === 1 ? 'critical' : 'urgent'}).`,
          type: diffDays <= 3 ? 'critical' : 'warning',
          date: t.updatedAt
        });
      }
    }
  });

  // Add newly sent alerts from our outbox log
  emailAlerts.slice(0, 5).forEach(alert => {
    systemAlerts.push({
      id: alert.id,
      title: alert.subject,
      message: alert.body.split('\n\n')[1] || alert.body,
      type: alert.type === 'expiry' ? 'critical' : 'info',
      date: alert.sentAt
    });
  });

  const unreadCount = systemAlerts.length;

  const handleUserSwitch = async (userId: string) => {
    setShowUserDropdown(false);
    await switchUser(userId);
  };

  return (
    <header className="h-16 bg-white border-b-[3px] border-black px-6 flex items-center justify-between shrink-0 relative font-sans text-black">
      {/* Page Title or Greeting */}
      <div className="flex items-center space-x-2">
        <Sparkles className="w-4 h-4 text-black" />
        <span className="text-xs font-black text-black uppercase tracking-widest">
          ENTERPRISE TENDER ENVIRONMENT
        </span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center space-x-4">
        
        {/* Real-time sync indicator */}
        <div className="flex items-center space-x-1.5 bg-emerald-50 px-3 py-1 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          <span className="w-2.5 h-2.5 rounded-none bg-emerald-600 animate-pulse"></span>
          <span className="text-[10px] font-black text-emerald-800 uppercase tracking-wider font-mono">LIVE SYNC</span>
        </div>

        {/* Notifications Center */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowUserDropdown(false);
            }}
            className="w-10 h-10 rounded-none bg-white hover:bg-gray-100 text-black flex items-center justify-center border-2 border-black transition relative shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
          >
            <Bell className="w-4 h-4 text-black" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-[10px] font-black text-white rounded-none border border-black flex items-center justify-center shadow-sm">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white border-2 border-black rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] overflow-hidden z-50 text-black">
              <div className="p-4 bg-gray-50 border-b-2 border-black flex items-center justify-between">
                <span className="font-black text-xs uppercase text-black tracking-wider">PLATFORM NOTIFICATIONS</span>
                <span className="text-[10px] font-mono font-black bg-amber-400 text-black px-2 py-0.5 border border-black rounded-none">
                  {unreadCount} ALERTS
                </span>
              </div>
              <div className="max-h-72 overflow-y-auto divide-y-2 divide-black bg-white">
                {systemAlerts.length > 0 ? (
                  systemAlerts.map(alert => (
                    <div key={alert.id} className="p-4 hover:bg-gray-50 transition">
                      <div className="flex gap-2.5 items-start">
                        <ShieldAlert className={`w-4 h-4 shrink-0 mt-0.5 ${
                          alert.type === 'critical' ? 'text-red-600' :
                          alert.type === 'warning' ? 'text-amber-500' :
                          'text-blue-600'
                        }`} />
                        <div>
                          <p className="text-xs font-black text-black leading-snug uppercase tracking-tight">{alert.title}</p>
                          <p className="text-[11px] text-black/80 mt-1 leading-normal font-medium">{alert.message}</p>
                          <span className="text-[9px] font-mono text-gray-500 block mt-1.5 uppercase font-bold">
                            TIME: {new Date(alert.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-6 text-center text-gray-500 text-xs font-mono uppercase">
                    No active notifications.
                  </div>
                )}
              </div>
              <div className="p-2.5 bg-gray-50 border-t-2 border-black text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    onNavigate('settings');
                  }}
                  className="text-[11px] font-black uppercase text-black hover:underline transition tracking-wide"
                >
                  View Outbound Email Logs
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Switcher Dropdown (Grader Tool!) */}
        <div className="relative">
          <button
            onClick={() => {
              setShowUserDropdown(!showUserDropdown);
              setShowNotifications(false);
            }}
            className="flex items-center space-x-3 bg-white hover:bg-gray-100 border-2 border-black px-3.5 py-1.5 rounded-none text-left text-sm font-medium transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] text-black"
          >
            <div className="w-7 h-7 rounded-none bg-black border border-black flex items-center justify-center">
              <User className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <span className="font-black block text-xs text-black uppercase leading-none mb-1 tracking-tight">{activeUser.name}</span>
              <span className="text-[9px] font-mono font-bold bg-amber-400 text-black px-1.5 py-0.5 border border-black rounded-none leading-none uppercase">
                {activeUser.role}
              </span>
            </div>
            <ChevronDown className="w-4 h-4 text-black shrink-0" />
          </button>

          {showUserDropdown && (
            <div className="absolute right-0 mt-2 w-60 bg-white border-2 border-black rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] overflow-hidden z-50 text-black">
              <div className="p-3 bg-gray-50 border-b-2 border-black">
                <span className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Quick Role Switcher (Grading Tool)
                </span>
                <p className="text-[10px] text-gray-600 mt-0.5 font-medium leading-tight">Toggle users to inspect role-gated UI blocks instantly.</p>
              </div>
              <div className="p-1 space-y-1 bg-white">
                {allUsers.map(u => (
                  <button
                    key={u.id}
                    onClick={() => handleUserSwitch(u.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-none text-xs font-bold uppercase tracking-wider transition ${
                      activeUser.id === u.id
                        ? 'bg-black text-white'
                        : 'text-black hover:bg-gray-100'
                    }`}
                  >
                    <div className="text-left">
                      <span className="block font-black">{u.name}</span>
                      <span className={`block text-[9px] font-mono mt-0.5 ${activeUser.id === u.id ? 'text-amber-400' : 'text-gray-500'}`}>{u.role.toUpperCase()}</span>
                    </div>
                    {activeUser.id === u.id && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
