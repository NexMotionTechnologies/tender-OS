import React, { useState } from 'react';
import { useApiStore } from '../store';
import { Settings, UserPlus, Users, Bell, Database, Mail, ArrowRight, CheckCircle2, ShieldAlert } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { allUsers, inviteTeamMember, emailAlerts, activeUser } = useApiStore();
  const [activeTab, setActiveTab] = useState<'team' | 'outbox' | 'templates'>('team');

  // Invite states
  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('pm');
  const [isInviting, setIsInviting] = useState(false);
  const [inviteSuccessMsg, setInviteSuccessMsg] = useState<string | null>(null);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName || !inviteEmail) return;

    setIsInviting(true);
    setInviteSuccessMsg(null);
    try {
      await inviteTeamMember({
        name: inviteName,
        email: inviteEmail,
        role: inviteRole,
      });
      setInviteSuccessMsg(`✓ Successfully provisioned and invited ${inviteName} as a ${inviteRole.toUpperCase()}!`);
      // Reset
      setInviteName('');
      setInviteEmail('');
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Invitation failed.');
    } finally {
      setIsInviting(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      
      {/* Top Header */}
      <div className="shrink-0 flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-black flex items-center gap-2 uppercase">
            <Settings className="w-6 h-6 text-black stroke-[2.5]" /> Platform & Workspace Settings
          </h1>
          <p className="text-xs font-bold text-neutral-600 mt-1 uppercase">
            Manage procurement team credentials, default file profiles, and inspect automated email alert logs.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="shrink-0 flex border-b-4 border-black gap-6 text-black">
        <button
          onClick={() => setActiveTab('team')}
          className={`pb-3 text-xs font-black border-b-4 transition uppercase tracking-wider ${
            activeTab === 'team'
              ? 'border-amber-400 text-black'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          Team Credentials
        </button>

        <button
          onClick={() => setActiveTab('outbox')}
          className={`pb-3 text-xs font-black border-b-4 transition uppercase tracking-wider ${
            activeTab === 'outbox'
              ? 'border-amber-400 text-black'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          Simulated Outbox Alerts ({emailAlerts.length})
        </button>

        <button
          onClick={() => setActiveTab('templates')}
          className={`pb-3 text-xs font-black border-b-4 transition uppercase tracking-wider ${
            activeTab === 'templates'
              ? 'border-amber-400 text-black'
              : 'border-transparent text-neutral-500 hover:text-black'
          }`}
        >
          Compliance Document Profiles
        </button>
      </div>

      {/* Tab Panels */}
      <div className="flex-1">
        
        {/* TAB 1: Team Credentials */}
        {activeTab === 'team' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* List Teammates */}
            <div className="lg:col-span-2 bg-white border-[3px] border-black p-6 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <h3 className="font-black text-xs text-black flex items-center gap-2 pb-3 border-b-2 border-black uppercase">
                <Users className="w-4 h-4 text-black stroke-[2.5]" /> Authorized Team Roster
              </h3>

              <div className="space-y-3">
                {allUsers.map(user => (
                  <div
                    key={user.id}
                    className="p-3.5 bg-white rounded-none border-2 border-black flex items-center justify-between text-xs text-black"
                  >
                    <div>
                      <span className="font-black text-black block uppercase">{user.name}</span>
                      <span className="text-[10px] text-neutral-500 font-mono font-bold block mt-0.5">{user.email}</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-none font-mono uppercase tracking-wider text-[10px] font-black border-2 border-black bg-white text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
                      user.role === 'ceo' ? 'bg-amber-100' :
                      user.role === 'pm' ? 'bg-indigo-100' :
                      'bg-gray-100'
                    }`}>
                      {user.role}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Invite Teammate Form - restricted for non-CEOs */}
            <div className="bg-white border-[3px] border-black p-6 flex flex-col justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
              <div>
                <h3 className="font-black text-xs text-black flex items-center gap-2 pb-3 border-b-2 border-black uppercase">
                  <UserPlus className="w-4 h-4 text-black stroke-[2.5]" /> Provision Team Member
                </h3>

                {activeUser.role !== 'ceo' ? (
                  <div className="p-4 bg-red-100 rounded-none border-2 border-black text-xs text-red-900 mt-6 space-y-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-bold uppercase">
                    <ShieldAlert className="w-5 h-5 text-red-600 stroke-[2.5]" />
                    <span className="font-black block text-red-600">Privilege Gated</span>
                    Only the Chief Executive Officer (CEO) is authorized to provision new team members.
                  </div>
                ) : (
                  <form onSubmit={handleInvite} className="space-y-4 mt-6">
                    {inviteSuccessMsg && (
                      <div className="p-3 bg-emerald-100 border-2 border-emerald-400 text-xs text-emerald-800 font-bold uppercase rounded-none">
                        {inviteSuccessMsg}
                      </div>
                    )}

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-black uppercase block tracking-wider">Full Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g., Sibusiso Khumalo"
                        value={inviteName}
                        onChange={e => setInviteName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/10"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-black uppercase block tracking-wider">Email Address</label>
                      <input
                        type="email"
                        required
                        placeholder="e.g., sibusiso@nexmotion.co.za"
                        value={inviteEmail}
                        onChange={e => setInviteEmail(e.target.value)}
                        className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/10"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-black uppercase block tracking-wider">System Role</label>
                      <select
                        value={inviteRole}
                        onChange={e => setInviteRole(e.target.value)}
                        className="w-full px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/10"
                      >
                        <option value="pm">Project Manager (PM)</option>
                        <option value="viewer">Bid Reviewer / Viewer</option>
                        <option value="ceo">Chief Executive Officer (CEO)</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={isInviting}
                      className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition disabled:opacity-55 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                    >
                      {isInviting ? 'Provisioning...' : 'Provision & Invite'}
                    </button>
                  </form>
                )}
              </div>

              <p className="text-[10px] text-neutral-600 leading-normal mt-6 bg-gray-150 p-3 rounded-none border-2 border-black font-bold uppercase">
                💡 Only provisioned team members can successfully complete the OAuth verification check during portal logins.
              </p>
            </div>

          </div>
        )}

        {/* TAB 2: Automated Outbox Logs */}
        {activeTab === 'outbox' && (
          <div className="bg-white border-[3px] border-black p-6 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
            <h3 className="font-black text-xs text-black flex items-center gap-2 pb-3 border-b-2 border-black uppercase">
              <Bell className="w-4 h-4 text-black stroke-[2.5]" /> Automated Sourcing Email Logs
            </h3>

            <p className="text-xs text-neutral-600 font-bold uppercase">
              NexMotion TMS automatically polls deadlines daily at 06:00 SAST and dispatches alerts to targeted assigned personnels. 
              The list below represents the audit trail log of simulated emails dispatched.
            </p>

            <div className="space-y-3.5 pt-3">
              {emailAlerts.length > 0 ? (
                emailAlerts.map(alert => (
                  <div
                    key={alert.id}
                    className="p-4 bg-white rounded-none border-2 border-black text-xs flex gap-4 items-start shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-black"
                  >
                    <div className="p-2 bg-amber-400 text-black border-2 border-black rounded-none shrink-0">
                      <Mail className="w-5 h-5 stroke-[2.5]" />
                    </div>
                    <div className="space-y-1 flex-1">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                        <span className="font-black text-black text-xs uppercase tracking-tight">{alert.subject}</span>
                        <span className="text-[10px] text-neutral-500 font-mono font-bold uppercase">
                          Dispatched: {new Date(alert.sentAt).toLocaleString('en-ZA')}
                        </span>
                      </div>
                      <div className="text-[11px] text-neutral-600 font-semibold uppercase">
                        Recipient: <strong className="text-black font-black">{alert.recipientEmail}</strong> • Type:{' '}
                        <span className="font-mono text-[10px] uppercase text-amber-600 font-black">{alert.type}</span>
                      </div>
                      <pre className="text-[11px] text-black bg-neutral-50 p-2.5 rounded-none border-2 border-black mt-2 font-mono whitespace-pre-wrap leading-relaxed">
                        {alert.body}
                      </pre>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-neutral-500 font-bold uppercase italic py-8 text-center">No email notifications dispatched yet.</p>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: Default Templates Map */}
        {activeTab === 'templates' && (
          <div className="bg-white border-[3px] border-black p-6 space-y-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
            <h3 className="font-black text-xs text-black flex items-center gap-2 pb-3 border-b-2 border-black uppercase">
              <Database className="w-4 h-4 text-black stroke-[2.5]" /> Reusable Compliance templates Map
            </h3>

            <p className="text-xs text-neutral-600 font-bold uppercase">
              Configure default files for fast single-click compliance checklist auto-completions. 
              When a new ICT tender demands these forms, NexMotion will pull the current pre-approved vault asset version.
            </p>

            <div className="space-y-3.5 pt-3">
              
              <div className="p-4 bg-white rounded-none border-2 border-black flex items-center justify-between text-xs text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div>
                  <span className="font-black text-black block uppercase">SARS Tax pin</span>
                  <span className="text-[11px] text-neutral-500 font-mono font-bold block mt-0.5">Template profile map category: <code>taxClearance</code></span>
                </div>
                <span className="text-emerald-800 font-mono text-[11px] font-black bg-emerald-100 px-2.5 py-0.5 rounded-none border-2 border-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] uppercase">
                  Mapped & Active
                </span>
              </div>

              <div className="p-4 bg-white rounded-none border-2 border-black flex items-center justify-between text-xs text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div>
                  <span className="font-black text-black block uppercase">B-BBEE Affidavit</span>
                  <span className="text-[11px] text-neutral-500 font-mono font-bold block mt-0.5">Template profile map category: <code>bbbee</code></span>
                </div>
                <span className="text-emerald-800 font-mono text-[11px] font-black bg-emerald-100 px-2.5 py-0.5 rounded-none border-2 border-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] uppercase">
                  Mapped & Active
                </span>
              </div>

              <div className="p-4 bg-white rounded-none border-2 border-black flex items-center justify-between text-xs text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div>
                  <span className="font-black text-black block uppercase">COIDA Good Standing Letter</span>
                  <span className="text-[11px] text-neutral-500 font-mono font-bold block mt-0.5">Template profile map category: <code>coida</code></span>
                </div>
                <span className="text-emerald-800 font-mono text-[11px] font-black bg-emerald-100 px-2.5 py-0.5 rounded-none border-2 border-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)] uppercase">
                  Mapped & Active
                </span>
              </div>

            </div>
          </div>
        )}

      </div>

    </div>
  );
};
