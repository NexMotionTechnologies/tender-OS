import React from 'react';
import { useApiStore } from '../store';
import { BarChart3, Download, TrendingUp, Trophy, Sparkles, PieChart, Landmark, Calendar, FileText } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { analytics, tenders, activeUser } = useApiStore();

  if (!activeUser || activeUser.role === 'viewer') {
    return (
      <div className="p-8 text-center max-w-md mx-auto bg-white border-4 border-black rounded-none shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] mt-16 font-sans text-black">
        <Landmark className="w-12 h-12 text-black mx-auto mb-4 stroke-[2.5]" />
        <h2 className="text-lg font-black uppercase text-black">Access Restricted</h2>
        <p className="text-sm text-neutral-700 mt-2 font-semibold">
          Business intelligence and corporate analytics are restricted to corporate executives (CEO) and PM roles.
        </p>
      </div>
    );
  }

  // Calculate high-level pipeline financials
  const submittedTenders = tenders.filter(t => t.status === 'submitted');
  const wonTenders = tenders.filter(t => t.status === 'won');

  const totalSubmittedVal = submittedTenders.reduce((sum, t) => sum + (t.bid?.bidValue || t.budget.max), 0);
  const totalWonVal = wonTenders.reduce((sum, t) => sum + (t.bid?.bidValue || t.budget.max), 0);

  const averageDealSize = submittedTenders.length > 0 
    ? Math.round(totalSubmittedVal / submittedTenders.length) 
    : 0;

  // CSV Exporter
  const handleCSVExport = () => {
    // Generate headers and rows
    const headers = ['Tender ID', 'Title', 'Organ of State', 'Province', 'Category', 'Budget Min', 'Budget Max', 'Status', 'Bid Value', 'Closing Date'];
    const rows = tenders.map(t => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.municipality.replace(/"/g, '""')}"`,
      t.province,
      t.category,
      t.budget.min,
      t.budget.max,
      t.status,
      t.bid?.bidValue || '',
      t.deadline
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `NexMotion_Tender_Analytics_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      
      {/* Top Header */}
      <div className="shrink-0 flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-black flex items-center gap-2 uppercase">
            <BarChart3 className="w-6 h-6 text-black stroke-[2.5]" /> Procurement Intelligence
          </h1>
          <p className="text-xs font-bold text-neutral-600 mt-1 uppercase">
            Track bidding velocity, conversion rates, and revenue forecasts across South African municipalities.
          </p>
        </div>

        <button
          onClick={handleCSVExport}
          className="px-4 py-2 bg-white border-2 border-black hover:bg-gray-100 text-black text-xs font-black uppercase tracking-wider rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex items-center gap-2 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] self-start md:self-center"
        >
          <Download className="w-4 h-4 text-black stroke-[2.5]" /> Export Tender Ledger (.CSV)
        </button>
      </div>

      {/* Financial KPIs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1 */}
        <div className="bg-white border-2 border-black p-5 rounded-none space-y-1.5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Total Bids Submitted</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-black">R{(totalSubmittedVal / 1000000).toFixed(1)}M</span>
            <span className="text-xs font-bold text-neutral-500">({submittedTenders.length} PROPOSALS)</span>
          </div>
          <p className="text-[9px] font-bold text-neutral-400 uppercase">Aggregate capital currently under review</p>
        </div>

        {/* KPI 2 */}
        <div className="bg-white border-2 border-black p-5 rounded-none space-y-1.5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Total Bids Awarded</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-emerald-600">R{(totalWonVal / 1000000).toFixed(1)}M</span>
            <span className="text-xs font-bold text-neutral-500">({wonTenders.length} WINS)</span>
          </div>
          <p className="text-[9px] font-bold text-neutral-400 uppercase">Secured enterprise contract value</p>
        </div>

        {/* KPI 3 */}
        <div className="bg-white border-2 border-black p-5 rounded-none space-y-1.5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Average Deal Value</span>
          <span className="text-2xl font-black text-black block">R{(averageDealSize / 1000000).toFixed(1)}M</span>
          <p className="text-[9px] font-bold text-neutral-400 uppercase">Mean threshold across submitted proposals</p>
        </div>

        {/* KPI 4 */}
        <div className="bg-white border-2 border-black p-5 rounded-none space-y-1.5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Conversion Yield</span>
          <span className="text-2xl font-black text-black block">
            {submittedTenders.length > 0 ? Math.round((wonTenders.length / submittedTenders.length) * 100) : 0}%
          </span>
          <p className="text-[9px] font-bold text-neutral-400 uppercase">Won-to-submitted submission ratio</p>
        </div>

      </div>

      {/* Analytics Main Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Monthly Historical Performance (Bar representation) */}
        <div className="lg:col-span-2 bg-white border-[3px] border-black rounded-none p-6 flex flex-col h-[400px] shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center justify-between pb-4 border-b-2 border-black shrink-0">
            <h3 className="font-black text-sm text-black flex items-center gap-2 uppercase tracking-wider">
              <TrendingUp className="w-4 h-4 text-black stroke-[2.5]" /> Bid Performance Trend (Last 3 Months)
            </h3>
            <span className="text-[9px] text-neutral-500 font-mono font-black uppercase">Simulated Business Forecasts</span>
          </div>

          <div className="flex-1 flex items-end justify-around pt-8 pb-4">
            {analytics.map((monthData, idx) => {
              const maxSubmitted = Math.max(...analytics.map(a => a.submittedValue));
              const heightPct = maxSubmitted > 0 ? (monthData.submittedValue / maxSubmitted) * 100 : 10;

              return (
                <div key={idx} className="flex flex-col items-center space-y-4 w-full max-w-[100px]">
                  {/* Bars */}
                  <div className="flex items-end gap-3 h-44 w-full justify-center">
                    
                    {/* Submitted Bar */}
                    <div className="w-7 bg-amber-400 hover:bg-amber-300 border-2 border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition relative group cursor-help" style={{ height: `${heightPct * 0.8}%` }}>
                      <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-white text-black px-2 py-1 border-2 border-black rounded-none text-[9px] font-black whitespace-nowrap opacity-0 group-hover:opacity-100 transition z-50 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        SUBMITTED: R{(monthData.submittedValue / 1000000).toFixed(1)}M
                      </div>
                    </div>

                    {/* Won Bar */}
                    <div className="w-7 bg-emerald-400 hover:bg-emerald-300 border-2 border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition relative group cursor-help" style={{ height: `${(monthData.wonValue / (maxSubmitted || 1)) * 100 * 0.8}%` }}>
                      <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-white text-black px-2 py-1 border-2 border-black rounded-none text-[9px] font-black whitespace-nowrap opacity-0 group-hover:opacity-100 transition z-50 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        WON: R{(monthData.wonValue / 1000000).toFixed(1)}M
                      </div>
                    </div>

                  </div>

                  {/* Month Label */}
                  <div className="text-center">
                    <span className="text-xs font-black text-black block uppercase tracking-tight">{monthData.month}</span>
                    <span className="text-[10px] text-neutral-600 font-mono font-black uppercase">Win Ratio: {monthData.winRatio}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Column: Sourcing Category breakdown */}
        <div className="bg-white border-[3px] border-black rounded-none p-6 flex flex-col justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div>
            <h3 className="font-black text-sm text-black flex items-center gap-2 pb-3 border-b-2 border-black uppercase tracking-wider">
              <PieChart className="w-4 h-4 text-black stroke-[2.5]" /> Sourcing Categories
            </h3>

            {/* List category breakdowns */}
            <div className="space-y-4 mt-6">
              
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold uppercase">
                  <span className="text-black">Software Development</span>
                  <span className="text-neutral-500 font-mono">4 Opportunities</span>
                </div>
                <div className="w-full bg-white border-2 border-black h-4 rounded-none overflow-hidden">
                  <div className="bg-amber-400 h-full w-[60%] border-r border-black"></div>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold uppercase">
                  <span className="text-black">Infrastructure & Hardware</span>
                  <span className="text-neutral-500 font-mono">2 Opportunities</span>
                </div>
                <div className="w-full bg-white border-2 border-black h-4 rounded-none overflow-hidden">
                  <div className="bg-amber-400 h-full w-[30%] border-r border-black"></div>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold uppercase">
                  <span className="text-black">Cloud Services</span>
                  <span className="text-neutral-500 font-mono">1 Opportunity</span>
                </div>
                <div className="w-full bg-white border-2 border-black h-4 rounded-none overflow-hidden">
                  <div className="bg-amber-400 h-full w-[10%] border-r border-black"></div>
                </div>
              </div>

            </div>
          </div>

          <div className="p-3.5 bg-amber-50 border-2 border-black rounded-none text-[11px] text-black font-semibold leading-snug mt-6 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            💡 <strong>SOURCING TIP:</strong> Gauteng Province (GP) has demonstrated a 15% higher bidding yield compared to Limpopo and Free State this quarter.
          </div>
        </div>

      </div>

    </div>
  );
};
