import React, { useState } from 'react';
import { useApiStore } from '../store';
import { Tender, TenderStatus } from '../types';
import { Kanban, ArrowLeft, ArrowRight, Star, Clock, AlertCircle, Sparkles, User, FileText } from 'lucide-react';

interface PipelineViewProps {
  onNavigate: (view: string, targetId?: string) => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({ onNavigate }) => {
  const { tenders, updateTenderStatus, allUsers, activeUser } = useApiStore();
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  const columns: { id: TenderStatus; title: string; color: string; border: string; bg: string }[] = [
    { id: 'identified', title: 'Identified', color: 'text-neutral-900', border: 'border-black', bg: 'bg-sky-50' },
    { id: 'shortlisted', title: 'Shortlisted', color: 'text-neutral-900', border: 'border-black', bg: 'bg-amber-50' },
    { id: 'preparing', title: 'Preparing', color: 'text-neutral-900', border: 'border-black', bg: 'bg-indigo-50' },
    { id: 'submitted', title: 'Submitted', color: 'text-neutral-900', border: 'border-black', bg: 'bg-emerald-50' },
    { id: 'won', title: 'Won', color: 'text-neutral-900', border: 'border-black', bg: 'bg-teal-50' },
    { id: 'lost', title: 'Lost', color: 'text-neutral-900', border: 'border-black', bg: 'bg-red-50' },
  ];

  const handleMove = async (tenderId: string, direction: 'left' | 'right') => {
    if (activeUser?.role === 'viewer') return; // Viewers are read-only!

    const tender = tenders.find(t => t.id === tenderId);
    if (!tender) return;

    const currentIdx = columns.findIndex(col => col.id === tender.status);
    if (currentIdx === -1) return;

    let targetIdx = currentIdx;
    if (direction === 'left' && currentIdx > 0) targetIdx--;
    if (direction === 'right' && currentIdx < columns.length - 1) targetIdx++;

    if (targetIdx !== currentIdx) {
      const nextStatus = columns[targetIdx].id;
      await updateTenderStatus(tenderId, nextStatus);
    }
  };

  const handleCardKeyDown = (e: React.KeyboardEvent, tenderId: string) => {
    if (activeUser?.role === 'viewer') return;

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      handleMove(tenderId, 'right');
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      handleMove(tenderId, 'left');
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onNavigate('tenders-new', tenderId); // Clicking opens detail
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-hidden max-w-7xl mx-auto w-full font-sans text-black">
      
      {/* Header section */}
      <div className="shrink-0 flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-black flex items-center gap-2 uppercase">
            <Kanban className="w-6 h-6 text-black stroke-[2.5]" /> Sourcing Kanban Pipeline
          </h1>
          <p className="text-xs font-bold text-neutral-600 mt-1 uppercase">
            Drag, shift, or use keyboard arrows to track procurement status. Real-time synchronised.
          </p>
        </div>
        
        {/* Help tooltip for keyboard navigation */}
        <div className="hidden sm:flex items-center gap-2 text-[10px] font-black uppercase text-black bg-white px-3 py-1.5 rounded-none border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          <kbd className="px-1.5 py-0.5 bg-neutral-100 border border-black rounded-none text-[10px] text-black font-mono font-black">◀</kbd>
          <kbd className="px-1.5 py-0.5 bg-neutral-100 border border-black rounded-none text-[10px] text-black font-mono font-black">▶</kbd>
          <span>+ <kbd className="px-1.5 py-0.5 bg-neutral-100 border border-black rounded-none text-[10px] text-black font-mono font-black">Enter</kbd> to move and inspect</span>
        </div>
      </div>

      {/* Kanban Board Container */}
      <div className="flex-1 flex gap-4 overflow-x-auto pb-4 select-none min-h-0">
        {columns.map(column => {
          const colTenders = tenders.filter(t => t.status === column.id);

          return (
            <div
              key={column.id}
              className={`w-72 shrink-0 flex flex-col h-full rounded-none border-2 ${column.border} ${column.bg} p-3.5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]`}
            >
              {/* Column Header */}
              <div className="flex items-center justify-between shrink-0 mb-4 pb-2 border-b-2 border-black">
                <div className="flex items-center space-x-2">
                  <span className={`w-2.5 h-2.5 rounded-none border border-black ${
                    column.id === 'identified' ? 'bg-sky-400' :
                    column.id === 'shortlisted' ? 'bg-amber-400' :
                    column.id === 'preparing' ? 'bg-indigo-400' :
                    column.id === 'submitted' ? 'bg-emerald-400' :
                    column.id === 'won' ? 'bg-teal-400' : 'bg-rose-400'
                  }`}></span>
                  <h3 className={`font-black text-xs uppercase tracking-wider ${column.color}`}>
                    {column.title}
                  </h3>
                </div>
                <span className="text-[10px] font-mono font-black bg-white px-2 py-0.5 rounded-none text-black border-2 border-black shadow-[1.5px_1.5px_0px_0px_rgba(0,0,0,1)]">
                  {colTenders.length}
                </span>
              </div>

              {/* Column Body / Cards List */}
              <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 min-h-0">
                {colTenders.length > 0 ? (
                  colTenders.map(tender => {
                    // Deadline proximity calculation
                    const dlDate = new Date(tender.deadline);
                    const now = new Date('2026-07-06T03:45:58-07:00');
                    const diffTime = dlDate.getTime() - now.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    const isUrgent = diffDays > 0 && diffDays <= 7;

                    const isSelected = selectedCardId === tender.id;

                    return (
                      <div
                        key={tender.id}
                        tabIndex={activeUser?.role !== 'viewer' ? 0 : -1}
                        onFocus={() => setSelectedCardId(tender.id)}
                        onBlur={() => setSelectedCardId(null)}
                        onKeyDown={e => handleCardKeyDown(e, tender.id)}
                        className={`bg-white hover:bg-neutral-50 p-4 rounded-none border-2 ${
                          isSelected ? 'border-amber-400 bg-amber-50/10' : 'border-black'
                        } cursor-pointer transition flex flex-col justify-between h-44 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[0.5px] hover:translate-y-[0.5px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-black focus:outline-none`}
                      >
                        {/* Upper Details */}
                        <div className="space-y-1.5" onClick={() => onNavigate('tenders-new', tender.id)}>
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[9px] font-mono font-black bg-neutral-100 px-1.5 py-0.5 rounded-none text-black border border-black truncate max-w-[60%] block uppercase">
                              {tender.municipality}
                            </span>
                            
                            {/* AI Fit Score badge */}
                            <span className={`text-[9px] font-mono font-black px-1.5 py-0.5 rounded-none flex items-center gap-1 border border-black shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] ${
                              tender.analysis.fitScore >= 85 ? 'bg-emerald-100 text-emerald-800' :
                              tender.analysis.fitScore >= 70 ? 'bg-amber-100 text-amber-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              <Sparkles className="w-2.5 h-2.5 shrink-0" />
                              {tender.analysis.fitScore}%
                            </span>
                          </div>
                          
                          <h4 className="font-black text-xs text-black leading-snug line-clamp-2 uppercase tracking-tight">
                            {tender.title}
                          </h4>
                        </div>

                        {/* Bottom Metadata & controls */}
                        <div className="pt-2 border-t border-dashed border-black mt-auto flex items-center justify-between">
                          
                          {/* Left: Deadline & Team Avatars */}
                          <div className="flex items-center space-x-2.5">
                            {/* Proximity / Date */}
                            <div className="flex items-center space-x-1 text-[10px] text-neutral-500">
                              <Clock className={`w-3.5 h-3.5 stroke-[2.5] ${isUrgent ? 'text-red-600 animate-pulse' : 'text-black'}`} />
                              <span className={isUrgent ? 'text-red-600 font-black uppercase' : 'font-bold uppercase'}>
                                {diffDays <= 0 ? 'Closed' : `${diffDays}d left`}
                              </span>
                            </div>

                            {/* Team avatars */}
                            <div className="flex -space-x-1.5 overflow-hidden">
                              {tender.assignedTo.length > 0 ? (
                                tender.assignedTo.map(uid => {
                                  const name = allUsers.find(u => u.id === uid)?.name || 'Team';
                                  return (
                                    <div
                                      key={uid}
                                      title={name}
                                      className="w-5 h-5 rounded-none bg-neutral-100 border border-black text-[9px] text-black flex items-center justify-center font-black uppercase font-mono"
                                    >
                                      {name.charAt(0)}
                                    </div>
                                  );
                                })
                              ) : (
                                <div title="Unassigned" className="w-5 h-5 rounded-none bg-white text-[9px] text-neutral-400 border border-black flex items-center justify-center font-bold">
                                  -
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right: Quick-move shift controllers (Hides for viewers) */}
                          {activeUser?.role !== 'viewer' && (
                            <div className="flex items-center space-x-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMove(tender.id, 'left');
                                }}
                                className="w-5 h-5 rounded-none bg-white border border-black text-black hover:bg-amber-400 flex items-center justify-center transition shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[0.5px] active:translate-y-[0.5px]"
                                title="Move left"
                              >
                                <ArrowLeft className="w-3 h-3 stroke-[2.5]" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMove(tender.id, 'right');
                                }}
                                className="w-5 h-5 rounded-none bg-white border border-black text-black hover:bg-amber-400 flex items-center justify-center transition shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[0.5px] active:translate-y-[0.5px]"
                                title="Move right"
                              >
                                <ArrowRight className="w-3 h-3 stroke-[2.5]" />
                              </button>
                            </div>
                          )}

                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-neutral-500 text-xs py-8 border-2 border-dashed border-black rounded-none uppercase font-bold bg-neutral-50">
                    No active tenders
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
