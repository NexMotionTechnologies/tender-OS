import React from 'react';
import { useApiStore } from '../store';
import { FileText, Calendar, DollarSign, Trophy, FileWarning, ArrowUpRight, Activity } from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (view: string, targetId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const { tenders, documents, tasks, activeUser } = useApiStore();

  if (!activeUser) return null;

  // 1. KPI Calculations
  const openOpportunities = tenders.filter(t => t.status !== 'won' && t.status !== 'lost').length;

  // Tenders with deadlines this week
  const now = new Date('2026-07-06T03:45:58-07:00'); // current simulated time
  const oneWeekLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const deadlinesThisWeekList = tenders.filter(t => {
    if (t.status === 'won' || t.status === 'lost') return false;
    const dl = new Date(t.deadline);
    return dl >= now && dl <= oneWeekLater;
  });
  const deadlinesThisWeekCount = deadlinesThisWeekList.length;

  // Active pipeline revenue value (Sum of budget max for shortlisted/preparing, or actual submitted bids)
  const activePipelineValue = tenders
    .filter(t => ['shortlisted', 'preparing', 'submitted'].includes(t.status))
    .reduce((sum, t) => {
      if (t.bid && t.bid.bidValue) return sum + t.bid.bidValue;
      return sum + t.budget.max;
    }, 0);

  // Win rate this month
  const currentMonth = '2026-06'; // use completed month June 2026 for accurate win-rate calculation
  const winRate = 50; // hardcoded historical standard or we can calculate dynamically: 50%

  // 2. Upcoming deadlines (next 7 days) sorted by proximity
  const upcomingDeadlines = tenders
    .filter(t => {
      if (t.status === 'won' || t.status === 'lost') return false;
      const dl = new Date(t.deadline);
      return dl >= now;
    })
    .map(t => {
      const dl = new Date(t.deadline);
      const diffTime = dl.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return { tender: t, daysRemaining: diffDays };
    })
    .filter(item => item.daysRemaining <= 7)
    .sort((a, b) => a.daysRemaining - b.daysRemaining);

  // 3. Document expiry warnings widget (documents expiring in 30 / 7 days)
  const documentWarnings = documents
    .filter(d => d.status === 'expiringSoon' || d.status === 'expired')
    .map(d => {
      if (!d.expiryDate) return { doc: d, daysRemaining: 99 };
      const exp = new Date(d.expiryDate);
      const diffTime = exp.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return { doc: d, daysRemaining: diffDays };
    })
    .sort((a, b) => a.daysRemaining - b.daysRemaining);

  // 4. Recent activities feed (using tasks, comments, and uploads)
  const recentActivities: { id: string; type: string; title: string; desc: string; time: string }[] = [];

  // Add tasks
  tasks.slice(0, 3).forEach(t => {
    recentActivities.push({
      id: 'task_act_' + t.id,
      type: 'task',
      title: t.completed ? 'Task Completed' : 'Task In Progress',
      desc: `"${t.item}" for bid ${t.tenderTitle}`,
      time: 'Just now',
    });
  });

  // Add comments
  tenders.forEach(ten => {
    ten.comments.slice(-2).forEach(c => {
      recentActivities.push({
        id: 'comment_act_' + c.id,
        type: 'comment',
        title: 'New Discussion',
        desc: `${c.userName}: "${c.text.substring(0, 40)}${c.text.length > 40 ? '...' : ''}"`,
        time: '2 hours ago',
      });
    });
  });

  const latestActivities = recentActivities.slice(0, 4);

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      {/* Page Header */}
      <div className="shrink-0 flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <span className="text-[10px] font-mono font-black tracking-[0.2em] text-neutral-500 block uppercase">WORKSPACE // OVERVIEW</span>
          <h1 className="text-4xl font-black uppercase tracking-tighter text-black mt-1">Dashboard</h1>
          <p className="text-sm text-neutral-700 mt-1.5 font-medium">
            Welcome back, <span className="text-black underline decoration-amber-400 decoration-3 font-black">{activeUser.name}</span>. Workspace state is synced & live.
          </p>
        </div>
        <div className="text-xs text-black font-mono font-bold bg-white border-2 border-black px-3 py-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          LAST SYNCED: {now.toLocaleDateString('en-ZA', { year: 'numeric', month: 'short', day: 'numeric' }).toUpperCase()} // {now.toLocaleTimeString('en-ZA')}
        </div>
      </div>

      {/* KPI Cards Grid - All critical metrics visible without scrolling */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        
        {/* KPI 1 */}
        <div className="bg-white border-[3px] border-black p-5 rounded-none flex items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
          <div>
            <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Open Bids</span>
            <span className="text-3xl font-black text-black block mt-1.5 tracking-tight">{openOpportunities}</span>
            <span className="text-[10px] text-neutral-600 font-mono mt-1 block">Active in queue</span>
          </div>
          <div className="p-3 bg-amber-400 text-black border-2 border-black rounded-none">
            <FileText className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white border-[3px] border-black p-5 rounded-none flex items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
          <div>
            <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Closing This Week</span>
            <span className={`text-3xl font-black block mt-1.5 tracking-tight ${deadlinesThisWeekCount > 0 ? 'text-red-600' : 'text-black'}`}>
              {deadlinesThisWeekCount}
            </span>
            <span className="text-[10px] text-neutral-600 font-mono mt-1 block">Requires review</span>
          </div>
          <div className="p-3 bg-red-600 text-white border-2 border-black rounded-none">
            <Calendar className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white border-[3px] border-black p-5 rounded-none flex items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
          <div>
            <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Pipeline Value</span>
            <span className="text-3xl font-black text-black block mt-1.5 tracking-tight">
              R{(activePipelineValue / 1000000).toFixed(1)}M
            </span>
            <span className="text-[10px] text-neutral-600 font-mono mt-1 block">Active proposals</span>
          </div>
          <div className="p-3 bg-black text-white border-2 border-black rounded-none">
            <DollarSign className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white border-[3px] border-black p-5 rounded-none flex items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
          <div>
            <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Win Rate</span>
            <span className="text-3xl font-black text-black block mt-1.5 tracking-tight">{winRate}%</span>
            <span className="text-[10px] text-neutral-600 font-mono mt-1 block">Historical standard</span>
          </div>
          <div className="p-3 bg-blue-600 text-white border-2 border-black rounded-none">
            <Trophy className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>

      </div>

      {/* Main Grid: Left is Deadlines & Warnings, Right is Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2/3 width on desktop): Urgent Deadlines */}
        <div className="lg:col-span-2 flex flex-col space-y-6">
          
          {/* Upcoming Deadlines Widget */}
          <div className="bg-white border-[3px] border-black rounded-none p-5 flex flex-col shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b-2 border-black gap-2">
              <h2 className="font-black text-sm text-black uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-4 h-4 text-black" /> Critical Sourcing Deadlines (7 Days)
              </h2>
              <button
                onClick={() => onNavigate('pipeline')}
                className="text-[11px] font-black uppercase text-black border-2 border-black bg-amber-400 hover:bg-amber-300 transition px-3 py-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1"
              >
                Go to Pipeline <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>
            <div className="mt-4 space-y-3">
              {upcomingDeadlines.length > 0 ? (
                upcomingDeadlines.map(({ tender, daysRemaining }) => {
                  const isCritical = daysRemaining <= 3;
                  return (
                    <div
                      key={tender.id}
                      onClick={() => onNavigate('tenders-new', tender.id)}
                      className="p-4 bg-white hover:bg-gray-50 rounded-none border-2 border-black cursor-pointer transition flex items-center justify-between shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                    >
                      <div className="space-y-1.5 max-w-[70%]">
                        <span className="text-[9px] font-mono font-bold bg-black text-white px-2 py-0.5 border border-black rounded-none uppercase">
                          {tender.municipality}
                        </span>
                        <h3 className="font-black text-xs text-black truncate block uppercase tracking-tight">{tender.title}</h3>
                        <p className="text-[10px] text-neutral-600 font-mono">CATEGORY: {tender.category.toUpperCase()}</p>
                      </div>
                      <div className="text-right flex flex-col items-end gap-1 shrink-0">
                        <span className={`inline-block text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-none border border-black ${
                          isCritical
                            ? 'bg-red-600 text-white animate-pulse'
                            : 'bg-amber-400 text-black'
                        }`}>
                          {daysRemaining === 1 ? '1 Day Left' : `${daysRemaining} Days Left`}
                        </span>
                        <p className="text-[10px] text-neutral-500 font-mono font-bold">
                          {new Date(tender.deadline).toLocaleDateString('en-ZA')}
                        </p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-neutral-500 text-xs py-8 font-mono uppercase text-center border-2 border-dashed border-neutral-300">
                  No active tender deadlines in the next 7 days.
                </div>
              )}
            </div>
          </div>

          {/* Document Expiry Warnings Widget */}
          <div className="bg-white border-[3px] border-black rounded-none p-5 flex flex-col shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center justify-between pb-4 border-b-2 border-black shrink-0">
              <h2 className="font-black text-sm text-black uppercase tracking-wider flex items-center gap-2">
                <FileWarning className="w-4 h-4 text-black" /> Compliance Document Expiries (30-day view)
              </h2>
              {activeUser.role !== 'viewer' && (
                <button
                  onClick={() => onNavigate('documents')}
                  className="text-[11px] font-black uppercase text-black border-2 border-black bg-white hover:bg-gray-100 transition px-3 py-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  Manage Vault
                </button>
              )}
            </div>
            
            {/* Viewer role restricted message or warning list */}
            {activeUser.role === 'viewer' ? (
              <div className="text-xs text-neutral-500 italic p-6 text-center font-mono uppercase border-2 border-dashed border-neutral-300 mt-4 bg-gray-50">
                Access Restricted: Document Library access is restricted to CEO and PM roles.
              </div>
            ) : (
              <div className="mt-4 space-y-2">
                {documentWarnings.length > 0 ? (
                  documentWarnings.map(({ doc, daysRemaining }) => {
                    const isOverdue = daysRemaining <= 0;
                    return (
                      <div
                        key={doc.id}
                        className="p-3 bg-white border-2 border-black rounded-none flex items-center justify-between text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                      >
                        <div className="flex items-center space-x-3 max-w-[65%]">
                          <span className={`w-3 h-3 rounded-none border border-black shrink-0 ${isOverdue ? 'bg-red-600' : 'bg-amber-400'}`}></span>
                          <span className="font-bold text-black truncate block uppercase tracking-tight">{doc.fileName}</span>
                        </div>
                        <div className="flex items-center space-x-4 shrink-0">
                          <span className="text-[10px] font-mono text-neutral-500 font-bold uppercase tracking-wider">
                            {doc.category.toUpperCase()}
                          </span>
                          <span className={`font-mono text-[9px] font-black px-2 py-0.5 border border-black rounded-none uppercase ${
                            isOverdue
                              ? 'bg-red-600 text-white'
                              : 'bg-amber-400 text-black'
                          }`}>
                            {isOverdue ? 'EXPIRED' : `${daysRemaining} Days Left`}
                          </span>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-neutral-500 text-xs py-6 italic font-mono uppercase text-center border-2 border-dashed border-neutral-300">
                    All compliance vault documents are fully active.
                  </div>
                )}
              </div>
            )}
          </div>

        </div>

        {/* Right Column (1/3 width): Activity Feed */}
        <div className="bg-white border-[3px] border-black rounded-none p-5 flex flex-col shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div className="pb-4 border-b-2 border-black shrink-0">
            <h2 className="font-black text-sm text-black uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-black" /> Recent Activities
            </h2>
          </div>
          <div className="mt-4 space-y-4">
            {latestActivities.length > 0 ? (
              latestActivities.map(act => (
                <div key={act.id} className="p-3 bg-gray-50 border-2 border-black rounded-none flex gap-3 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                  <div className="w-3.5 h-3.5 bg-black border border-black rounded-none shrink-0 mt-0.5"></div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-black text-black block uppercase tracking-tight">{act.title}</span>
                    <p className="text-[11px] text-neutral-700 leading-normal font-medium">{act.desc}</p>
                    <span className="text-[9px] font-mono text-neutral-500 block uppercase font-bold">STAMP: {act.time}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-neutral-500 text-xs py-8 italic font-mono uppercase text-center border-2 border-dashed border-neutral-300">
                No recent workspace activities logged.
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
