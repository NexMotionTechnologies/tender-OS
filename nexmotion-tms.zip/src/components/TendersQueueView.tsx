import React, { useState } from 'react';
import { useApiStore } from '../store';
import { FileText, Search, Plus, Sparkles, UploadCloud, Link, ArrowRight, ShieldAlert, CheckCircle, RefreshCw } from 'lucide-react';

interface TendersQueueViewProps {
  onNavigate: (view: string, targetId?: string) => void;
}

export const TendersQueueView: React.FC<TendersQueueViewProps> = ({ onNavigate }) => {
  const { tenders, createTender, runScraper, activeUser } = useApiStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [provinceFilter, setProvinceFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Manual Add Form Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isScraping, setIsScraping] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    link: '',
    source: 'Manual Upload',
    municipality: '',
    province: 'Gauteng',
    category: 'Software Development',
    budgetMin: '2000000',
    budgetMax: '4000000',
    deadline: '',
  });

  const provinces = ['All', 'Gauteng', 'Limpopo', 'Free State', 'Western Cape', 'KwaZulu-Natal'];
  const categories = ['All', 'Software Development', 'Hardware Supply', 'Infrastructure', 'Cloud Services', 'Cybersecurity', 'IT Consulting'];

  // Filter identified tenders primarily, but allow searching all
  const filteredTenders = tenders.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.municipality.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesProvince = provinceFilter === 'All' || t.province === provinceFilter;
    const matchesCategory = categoryFilter === 'All' || t.category === categoryFilter;
    
    // Only show "identified" or "shortlisted" in this queue view by default, or all if searching
    const isQueued = t.status === 'identified' || t.status === 'shortlisted' || searchTerm.length > 0;

    return matchesSearch && matchesProvince && matchesCategory && isQueued;
  });

  const handleManualAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    try {
      await createTender({
        ...formData,
        budgetMin: Number(formData.budgetMin),
        budgetMax: Number(formData.budgetMax),
      });
      setShowAddModal(false);
      // Reset form
      setFormData({
        title: '',
        link: '',
        source: 'Manual Upload',
        municipality: '',
        province: 'Gauteng',
        category: 'Software Development',
        budgetMin: '2000000',
        budgetMax: '4000000',
        deadline: '',
      });
    } catch (err) {
      console.error(err);
      alert('Tender creation or Gemini AI analysis failed. Please verify your fields.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRunScraper = async () => {
    setIsScraping(true);
    try {
      const newTender = await runScraper();
      // Optionally notify user
      alert(`Scraper run completed successfully! Discovered and analyzed: "${newTender.title}"`);
    } catch (err) {
      console.error(err);
      alert('Scraper execution failed.');
    } finally {
      setIsScraping(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full font-sans pb-16 text-black">
      
      {/* Top Header & Actions */}
      <div className="shrink-0 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 pb-4 border-b-4 border-black">
        <div>
          <span className="text-[10px] font-mono font-black tracking-[0.2em] text-neutral-500 block uppercase">GOVERNMENT PROCUREMENT SOURCING</span>
          <h1 className="text-3xl font-black uppercase tracking-tighter text-black flex items-center gap-2 mt-1">
            <FileText className="w-7 h-7 text-black stroke-[2.5]" /> Government Tenders Queue
          </h1>
          <p className="text-sm text-neutral-700 mt-1.5 font-medium">
            Browse discovered tenders. Ingest external specs or trigger automated scraping with Gemini AI.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Daily Scraper Trigger */}
          {activeUser?.role !== 'viewer' && (
            <button
              onClick={handleRunScraper}
              disabled={isScraping}
              className="px-4 py-2.5 bg-white border-2 border-black hover:bg-gray-100 text-black text-xs font-black uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] flex items-center gap-2 transition disabled:opacity-50 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              title="Daily scraper at 06:00 SAST"
            >
              <RefreshCw className={`w-4 h-4 text-black ${isScraping ? 'animate-spin text-amber-500' : ''}`} />
              {isScraping ? 'Scraping GP/LP/FS...' : 'Trigger Daily Scrape'}
            </button>
          )}

          {/* Ingest / Manual Add */}
          {activeUser?.role !== 'viewer' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-black text-xs font-black uppercase tracking-wider rounded-none border-2 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1.5 transition active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
            >
              <Plus className="w-4.5 h-4.5 stroke-[2.5]" /> Upload Tender (AI Analyze)
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="shrink-0 bg-white border-[3px] border-black p-4 rounded-none flex flex-col md:flex-row gap-4 items-center justify-between shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-3 w-4 h-4 text-black stroke-[2.5]" />
          <input
            type="text"
            placeholder="Search tenders, municipalities..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-white border-2 border-black rounded-none text-xs text-black placeholder-neutral-500 font-bold focus:outline-none focus:bg-amber-50/40 transition"
          />
        </div>

        <div className="flex flex-wrap gap-2.5 w-full md:w-auto justify-end">
          {/* Province Filter */}
          <select
            value={provinceFilter}
            onChange={e => setProvinceFilter(e.target.value)}
            className="px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/40"
          >
            {provinces.map(p => (
              <option key={p} value={p}>PROVINCE: {p.toUpperCase()}</option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/40"
          >
            {categories.map(c => (
              <option key={c} value={c}>CATEGORY: {c.toUpperCase()}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tenders List/Grid Table */}
      <div className="bg-white border-[3px] border-black rounded-none overflow-hidden flex flex-col shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-black">
        <div className="overflow-y-auto min-h-0">
          {filteredTenders.length > 0 ? (
            <div className="divide-y-2 divide-black">
              
              {/* Header row */}
              <div className="hidden md:flex items-center px-6 py-3.5 bg-gray-50 text-[10px] font-black text-black uppercase tracking-widest font-mono border-b-2 border-black">
                <div className="w-[45%]">Tender / Org</div>
                <div className="w-[15%]">Region</div>
                <div className="w-[15%] text-right">Budget</div>
                <div className="w-[15%] text-center">AI Fit Score</div>
                <div className="w-[10%] text-right">Action</div>
              </div>

              {/* Ingested rows */}
              {filteredTenders.map(tender => {
                const isShortlisted = tender.status === 'shortlisted';
                const score = tender.analysis.fitScore;
                const rec = tender.analysis.recommendation;

                return (
                  <div
                    key={tender.id}
                    onClick={() => onNavigate('tender-detail', tender.id)}
                    className="flex flex-col md:flex-row md:items-center px-6 py-5 hover:bg-gray-50 cursor-pointer transition gap-3"
                  >
                    {/* Title and source */}
                    <div className="w-full md:w-[45%] space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[9px] font-mono font-black bg-black text-white px-2 py-0.5 border border-black rounded-none uppercase">
                          {tender.source.toUpperCase()}
                        </span>
                        {isShortlisted && (
                          <span className="text-[9px] font-black bg-amber-400 text-black px-2 py-0.5 border border-black rounded-none uppercase">
                            Shortlisted
                          </span>
                        )}
                        {tender.status === 'preparing' && (
                          <span className="text-[9px] font-black bg-blue-600 text-white px-2 py-0.5 border border-black rounded-none uppercase">
                            Preparing Bid
                          </span>
                        )}
                      </div>
                      <h3 className="font-black text-sm text-black leading-snug uppercase tracking-tight hover:underline">
                        {tender.title}
                      </h3>
                      <p className="text-[10px] text-neutral-600 font-mono font-bold uppercase tracking-wider">CATEGORY: {tender.category.toUpperCase()}</p>
                    </div>

                    {/* Region */}
                    <div className="w-full md:w-[15%] space-y-1">
                      <span className="text-xs font-black text-black uppercase tracking-tight block">{tender.province}</span>
                      <span className="text-[10px] text-neutral-600 font-bold block truncate uppercase">{tender.municipality}</span>
                    </div>

                    {/* Budget */}
                    <div className="w-full md:w-[15%] md:text-right space-y-1">
                      <span className="text-xs font-black text-black block">
                        R{(tender.budget.min / 1000000).toFixed(1)}M - R{(tender.budget.max / 1000000).toFixed(1)}M
                      </span>
                      <span className="text-[10px] font-mono font-bold text-neutral-500 block">
                        DUE: {new Date(tender.deadline).toLocaleDateString('en-ZA')}
                      </span>
                    </div>

                    {/* AI Fit badge */}
                    <div className="w-full md:w-[15%] flex md:justify-center items-center gap-2">
                      <span className={`text-xs font-black px-2.5 py-1 rounded-none border-2 border-black flex items-center gap-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${
                        score >= 85 ? 'bg-emerald-400 text-black' :
                        score >= 70 ? 'bg-amber-400 text-black' :
                        'bg-red-500 text-white'
                      }`}>
                        <Sparkles className="w-3.5 h-3.5 shrink-0" />
                        {score}%
                      </span>

                      <span className={`text-[9px] uppercase font-mono font-black tracking-wider px-2 py-0.5 border border-black rounded-none ${
                        rec === 'Pursue' ? 'bg-emerald-400 text-black' :
                        rec === 'Maybe' ? 'bg-amber-400 text-black' :
                        'bg-gray-100 text-neutral-500'
                      }`}>
                        {rec}
                      </span>
                    </div>

                    {/* Action button */}
                    <div className="w-full md:w-[10%] flex md:justify-end">
                      <button className="p-2 border-2 border-black bg-white hover:bg-gray-100 rounded-none text-black transition shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    </div>

                  </div>
                );
              })}

            </div>
          ) : (
            <div className="text-neutral-500 text-xs py-16 font-mono uppercase text-center border-2 border-dashed border-neutral-300 m-6">
              No matching government tenders in this view filter.
            </div>
          )}
        </div>
      </div>

      {/* Manual Upload modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-xl bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 flex flex-col overflow-hidden max-h-[90vh] text-black">
            
            {/* Header */}
            <div className="pb-4 border-b-2 border-black shrink-0 flex items-center justify-between">
              <h2 className="font-black text-lg text-black uppercase tracking-tight flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-black" /> Ingest & Analyze New Tender
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-black hover:bg-gray-100 px-2.5 py-1 border-2 border-black font-black uppercase text-xs rounded-none transition"
              >
                Close
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleManualAdd} className="flex-1 overflow-y-auto space-y-5 pr-1 mt-4">
              
              <div className="bg-amber-50 border-2 border-black p-4 rounded-none flex gap-3 mb-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <UploadCloud className="w-6 h-6 text-black shrink-0 mt-0.5" />
                <div className="text-xs text-black">
                  <span className="font-black text-black uppercase block tracking-tight mb-0.5">Automatic Gemini Analysis</span>
                  Provide the tender's core information. Upon submission, our server-side Gemini AI engine 
                  will automatically parse constraints and compliance checklists for you.
                </div>
              </div>

              {/* Title */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                  Tender Title / Subject
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Gauteng Treasury: Provision of Datacenter Infrastructure..."
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black font-bold focus:outline-none focus:bg-amber-50/30 transition"
                />
              </div>

              {/* Grid 1 */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Organ of State / Municipality
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Polokwane Local Municipality"
                    value={formData.municipality}
                    onChange={e => setFormData({ ...formData, municipality: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black font-bold focus:outline-none focus:bg-amber-50/30 transition"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Province
                  </label>
                  <select
                    value={formData.province}
                    onChange={e => setFormData({ ...formData, province: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/30 transition"
                  >
                    {provinces.filter(p => p !== 'All').map(p => (
                      <option key={p} value={p}>{p.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Grid 2 */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/30 transition"
                  >
                    {categories.filter(c => c !== 'All').map(c => (
                      <option key={c} value={c}>{c.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Source Link (Paste Bulletin URL)
                  </label>
                  <input
                    type="text"
                    placeholder="https://www.etenders.gov.za/tenders/..."
                    value={formData.link}
                    onChange={e => setFormData({ ...formData, link: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black font-bold focus:outline-none focus:bg-amber-50/30 transition"
                  />
                </div>
              </div>

              {/* Grid 3 */}
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Min Budget (ZAR)
                  </label>
                  <input
                    type="number"
                    value={formData.budgetMin}
                    onChange={e => setFormData({ ...formData, budgetMin: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black font-bold focus:outline-none focus:bg-amber-50/30 transition"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Max Budget (ZAR)
                  </label>
                  <input
                    type="number"
                    value={formData.budgetMax}
                    onChange={e => setFormData({ ...formData, budgetMax: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs text-black font-bold focus:outline-none focus:bg-amber-50/30 transition"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-black uppercase tracking-wider block">
                    Closing Deadline
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.deadline}
                    onChange={e => setFormData({ ...formData, deadline: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-black rounded-none text-xs font-bold text-black focus:outline-none focus:bg-amber-50/30 transition"
                  />
                </div>
              </div>

              {/* Footer action buttons */}
              <div className="pt-4 border-t-2 border-black flex justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border-2 border-black bg-white hover:bg-gray-150 text-xs font-black uppercase tracking-wider rounded-none transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-black border-2 border-black font-black text-xs uppercase tracking-wider rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1.5 transition disabled:opacity-60 active:translate-x-[1px] active:translate-y-[1px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  {isUploading ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-none animate-spin"></span>
                      GEMINI ANALYZING...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 shrink-0" />
                      Add to Sourcing Queue
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
