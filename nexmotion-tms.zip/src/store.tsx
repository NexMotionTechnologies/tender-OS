import React, { createContext, useContext, useState, useEffect } from 'react';
import { Tender, Task, User, Document, AccessLog, EmailAlert, MonthlyAnalytics } from './types';

interface ApiStoreContextType {
  activeUser: User | null;
  allUsers: User[];
  tenders: Tender[];
  tasks: Task[];
  documents: Document[];
  emailAlerts: EmailAlert[];
  analytics: MonthlyAnalytics[];
  isLoading: boolean;
  error: string | null;
  refreshAll: (isBackground?: boolean) => Promise<void>;
  switchUser: (userId: string) => Promise<void>;
  createTender: (tenderData: any) => Promise<Tender>;
  analyzeTender: (id: string) => Promise<Tender>;
  updateTenderStatus: (id: string, status: string) => Promise<Tender>;
  updateChecklistItem: (id: string, itemIndex: number, completed?: boolean, assignedTo?: string, dueDate?: string) => Promise<Tender>;
  attachDocToChecklist: (id: string, itemIndex: number, documentId: string) => Promise<any>;
  submitBid: (id: string, bidValue: number) => Promise<Tender>;
  addComment: (id: string, text: string) => Promise<Tender>;
  assignTender: (id: string, userIds: string[]) => Promise<Tender>;
  toggleTask: (id: string) => Promise<Task>;
  uploadDocument: (docData: any) => Promise<Document>;
  uploadNewDocVersion: (id: string, verData: any) => Promise<Document>;
  logDocAccess: (id: string, action: 'view' | 'download') => Promise<AccessLog>;
  getDocLogs: (id: string) => Promise<AccessLog[]>;
  inviteTeamMember: (memberData: { name: string; email: string; role: string }) => Promise<User>;
  runScraper: () => Promise<Tender>;
  signUp: (signUpData: { name: string; email: string; role: string }) => Promise<User>;
  loginByEmail: (email: string, pin?: string, role?: string) => Promise<User>;
}

const ApiStoreContext = createContext<ApiStoreContextType | null>(null);

export function useApiStore() {
  const context = useContext(ApiStoreContext);
  if (!context) {
    throw new Error('useApiStore must be used within an ApiStoreProvider');
  }
  return context;
}

export const ApiStoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeUser, setActiveUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [tenders, setTenders] = useState<Tender[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [emailAlerts, setEmailAlerts] = useState<EmailAlert[]>([]);
  const [analytics, setAnalytics] = useState<MonthlyAnalytics[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const getQueryString = () => {
    const savedUserId = localStorage.getItem('nexmotion_user_id');
    return savedUserId ? `?userId=${savedUserId}` : '';
  };

  const getHeaders = () => {
    const savedUserId = localStorage.getItem('nexmotion_user_id');
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (savedUserId) {
      headers['X-Test-User-Id'] = savedUserId;
    }
    return headers;
  };

  const refreshAll = async (isBackground = false) => {
    const savedUserId = localStorage.getItem('nexmotion_user_id');
    if (!savedUserId) {
      if (!isBackground) {
        setIsLoading(true);
        setError(null);
      }
      try {
        const userRes = await fetch('/api/me');
        if (userRes.ok) {
          const userData = await userRes.json();
          setAllUsers(userData.allUsers || []);
        }
        setActiveUser(null);
      } catch (err) {
        console.error('Error refreshing guest state:', err);
      } finally {
        if (!isBackground) {
          setIsLoading(false);
        }
      }
      return;
    }

    if (!isBackground) {
      setIsLoading(true);
      setError(null);
    }
    try {
      const q = getQueryString();
      const headers = getHeaders();

      // Fetch active user
      const userRes = await fetch(`/api/me${q}`, { headers });
      const userData = await userRes.json();
      setActiveUser(userData.user);
      setAllUsers(userData.allUsers);

      if (userData.user) {
        // Fetch tenders
        const tendersRes = await fetch(`/api/tenders${q}`, { headers });
        if (tendersRes.ok) {
          const tendersData = await tendersRes.json();
          setTenders(tendersData);
        }

        // Fetch tasks
        const tasksRes = await fetch(`/api/tasks${q}`, { headers });
        if (tasksRes.ok) {
          const tasksData = await tasksRes.json();
          setTasks(tasksData);
        }

        // Fetch documents (CEO/PM only)
        if (userData.user.role !== 'viewer') {
          const docsRes = await fetch(`/api/documents${q}`, { headers });
          if (docsRes.ok) {
            const docsData = await docsRes.json();
            setDocuments(docsData);
          }

          const analRes = await fetch(`/api/analytics${q}`, { headers });
          if (analRes.ok) {
            const analData = await analRes.json();
            setAnalytics(analData);
          }
        } else {
          setDocuments([]);
          setAnalytics([]);
        }

        // Fetch email alerts outbox
        const alertsRes = await fetch(`/api/email-alerts${q}`, { headers });
        if (alertsRes.ok) {
          const alertsData = await alertsRes.json();
          setEmailAlerts(alertsData);
        }
      }
    } catch (err) {
      console.error('Error refreshing state:', err);
      if (!isBackground) {
        setError('Connection to backend failed. Please verify server status.');
      }
    } finally {
      if (!isBackground) {
        setIsLoading(false);
      }
    }
  };

  useEffect(() => {
    refreshAll();
    // Setup long poll or interval for simple "real-time" pipeline simulation
    const interval = setInterval(() => {
      // Background reload to simulate updates
      const savedUserId = localStorage.getItem('nexmotion_user_id');
      if (savedUserId) {
        refreshAll(true);
      }
    }, 10000); // refresh every 10s
    return () => clearInterval(interval);
  }, []);

  const switchUser = async (userId: string) => {
    localStorage.setItem('nexmotion_user_id', userId);
    try {
      const res = await fetch('/api/auth/switch-user', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ userId }),
      });
      if (res.ok) {
        await refreshAll();
      } else {
        throw new Error('Failed to switch user role.');
      }
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const createTender = async (tenderData: any) => {
    const res = await fetch(`/api/tenders${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(tenderData),
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to create tender');
    }
    const tender = await res.json();
    setTenders(prev => [tender, ...prev]);
    await refreshAll();
    return tender;
  };

  const analyzeTender = async (id: string) => {
    const res = await fetch(`/api/tenders/${id}/analyze${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
    });
    if (!res.ok) throw new Error('Analysis failed');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const updateTenderStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/tenders/${id}/status${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Failed to update status');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const updateChecklistItem = async (id: string, itemIndex: number, completed?: boolean, assignedTo?: string, dueDate?: string) => {
    const res = await fetch(`/api/tenders/${id}/checklist/update${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ itemIndex, completed, assignedTo, dueDate }),
    });
    if (!res.ok) throw new Error('Failed to update checklist item');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const attachDocToChecklist = async (id: string, itemIndex: number, documentId: string) => {
    const res = await fetch(`/api/tenders/${id}/checklist/attach-doc${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ itemIndex, documentId }),
    });
    if (!res.ok) throw new Error('Failed to attach document');
    const data = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? data.tender : t)));
    setDocuments(prev => prev.map(d => (d.id === documentId ? data.document : d)));
    await refreshAll();
    return data;
  };

  const submitBid = async (id: string, bidValue: number) => {
    const res = await fetch(`/api/tenders/${id}/submit${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ bidValue }),
    });
    if (!res.ok) throw new Error('Failed to submit bid');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const addComment = async (id: string, text: string) => {
    const res = await fetch(`/api/tenders/${id}/comments${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ text }),
    });
    if (!res.ok) throw new Error('Failed to post comment');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const assignTender = async (id: string, userIds: string[]) => {
    const res = await fetch(`/api/tenders/${id}/assign${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ userIds }),
    });
    if (!res.ok) throw new Error('Failed to update assignments');
    const tender = await res.json();
    setTenders(prev => prev.map(t => (t.id === id ? tender : t)));
    await refreshAll();
    return tender;
  };

  const toggleTask = async (id: string) => {
    const res = await fetch(`/api/tasks/${id}/toggle${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to toggle task');
    const task = await res.json();
    setTasks(prev => prev.map(t => (t.id === id ? task : t)));
    await refreshAll();
    return task;
  };

  const uploadDocument = async (docData: any) => {
    const res = await fetch(`/api/documents${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(docData),
    });
    if (!res.ok) throw new Error('Failed to upload document');
    const doc = await res.json();
    setDocuments(prev => [...prev, doc]);
    await refreshAll();
    return doc;
  };

  const uploadNewDocVersion = async (id: string, verData: any) => {
    const res = await fetch(`/api/documents/${id}/versions${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(verData),
    });
    if (!res.ok) throw new Error('Failed to update document version');
    const doc = await res.json();
    setDocuments(prev => prev.map(d => (d.id === id ? doc : d)));
    await refreshAll();
    return doc;
  };

  const logDocAccess = async (id: string, action: 'view' | 'download') => {
    const res = await fetch(`/api/documents/${id}/log-access${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ action }),
    });
    if (!res.ok) throw new Error('Failed to log document access');
    const log = await res.json();
    await refreshAll();
    return log;
  };

  const getDocLogs = async (id: string) => {
    const res = await fetch(`/api/documents/${id}/logs${getQueryString()}`, {
      headers: getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load document logs');
    return res.json();
  };

  const inviteTeamMember = async (memberData: { name: string; email: string; role: string }) => {
    const res = await fetch(`/api/settings/team/invite${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(memberData),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to invite team member');
    }
    const newUser = await res.json();
    await refreshAll();
    return newUser;
  };

  const runScraper = async () => {
    const res = await fetch(`/api/tenders/scrape${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
    });
    if (!res.ok) throw new Error('Scraper execution failed');
    const data = await res.json();
    setTenders(prev => [data.tender, ...prev]);
    await refreshAll();
    return data.tender;
  };

  const signUp = async (signUpData: { name: string; email: string; role: string }) => {
    const res = await fetch(`/api/auth/signup${getQueryString()}`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(signUpData),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to register account');
    }
    const data = await res.json();
    localStorage.setItem('nexmotion_user_id', data.user.id);
    await refreshAll();
    return data.user;
  };

  const loginByEmail = async (email: string, pin?: string, role?: string) => {
    const res = await fetch(`/api/auth/login-by-email`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, pin, role }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to authenticate');
    }
    const data = await res.json();
    localStorage.setItem('nexmotion_user_id', data.user.id);
    await refreshAll();
    return data.user;
  };

  return (
    <ApiStoreContext.Provider
      value={{
        activeUser,
        allUsers,
        tenders,
        tasks,
        documents,
        emailAlerts,
        analytics,
        isLoading,
        error,
        refreshAll,
        switchUser,
        createTender,
        analyzeTender,
        updateTenderStatus,
        updateChecklistItem,
        attachDocToChecklist,
        submitBid,
        addComment,
        assignTender,
        toggleTask,
        uploadDocument,
        uploadNewDocVersion,
        logDocAccess,
        getDocLogs,
        inviteTeamMember,
        runScraper,
        signUp,
        loginByEmail,
      }}
    >
      {children}
    </ApiStoreContext.Provider>
  );
};
